#include "Header.h"

int main()
{
	printf("@@@MONITOR@@@\n");

	socket_t s = socket(AF_UNIX,SOCK_STREAM,0);

	sockaddr_un socket_addr,client_addr;
	//sockaddr_un:
		//-> sun_family
		//-> sun_path

	socket_addr.sun_family=AF_UNIX;
	strcpy(socket_addr.sun_path,UNIXSTR_PATH);
	unlink(UNIXSTR_PATH);

	bind(s,(sockaddr*) &socket_addr,sizeof(sockaddr_un));

	/* Espera por 99 clientes */
	listen(s,99);

	int clientlen = sizeof(client_addr);
	client_t client;
	char c[BUFFER_SIZE];

	printf("À espera de clientes...\n");
	client = accept(s,(sockaddr*) &client_addr,&clientlen);	// Quando vierem, aceita clientes
	printf("Chegou alguem\n");

	//trinco_t m;
	//inicializarMutex(&m);
	//Fechar(&m);
	//Abrir(&m);
	//destruirMutex(&m);

	while(FOREVER)
	{
		read(client,c,BUFFER_SIZE);						// Lê o número
		printf("O simulador mandou:%i\n",atoi(c));			// Mostra o número
		trinco_t m;
	}
	return 0;
}
