#include "Header.h"

int main()
{
	printf("@@@SIMULADOR@@@\n");

	socket_t s = socket(AF_UNIX,SOCK_STREAM,0);
	//char buffer[1000];

	sockaddr_un socket_addr;
	//sockaddr_un:
		//-> sun_family
		//-> sun_path

	socket_addr.sun_family=AF_UNIX;
	strcpy(socket_addr.sun_path,UNIXSTR_PATH);

	/* Conecta-se ao outro socket ("servidor") */
	connect(s,(sockaddr*) &socket_addr,sizeof(sockaddr_un));
	printf("Conectou-se ao servidor.\n");

	char c[BUFFER_SIZE];
	int x = 0;
	while(FOREVER)
	{
		//gera números
		// ...
		sprintf(c,"%i",x);
		write(s,c,BUFFER_SIZE); //manda para o monitor
		x++;
	}


	return 0;
}
