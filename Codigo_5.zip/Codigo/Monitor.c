#include "Monitor.h"

void * criarThreadUtilizador()
{
    pthread_t t;
    pthread_create(&t,NULL,(void *)criarUtilizador,NULL);  
}


void main()
{
    fila_u * f_recbil = alocaFila();
    fila_u * f_monrussa = alocaFila();

    utilizador * u = criarUtilizador();
    utilizador * u2 = criarUtilizador();
    utilizador * u3 = criarUtilizador();
    
    inserirUtilizador(f_recbil,u);
    inserirUtilizador(f_recbil,u2);
    inserirUtilizador(f_recbil,u3);

    f_recbil = removerUtilizador(f_recbil,u);
    printf("Oi: %i\n",f_recbil->atual->id);
    //mostrarTodosOsIds(f_recbil);
}
