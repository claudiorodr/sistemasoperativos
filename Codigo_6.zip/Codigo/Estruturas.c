#include "Estruturas.h"

void mostrarTodosOsIds(fila_u * f)
{
    fila_u * aux = f;

    printf("%i\n",aux->atual->id);

    while(aux->seguinte!=NULL)
    {
        printf("%i\n",aux->seguinte->atual->id);
        aux = aux->seguinte;
    }
}

void inserirUtilizador(fila_u * f, utilizador * u)
{ 
    if(filaEstaVazia(f)) { colocarElementoNaFila(u,f); }

    else
    {
        fila_u * aux = f;
        
        while(!estiverNoFimDaFila(aux)) 
            aux = aux->seguinte;
            
        fila_u * aux_u = criarFila(u);

        aux->seguinte = aux_u;
    }
}

fila_u * removerUtilizador(fila_u * f, utilizador * u)
{
    if(!filaEstaVazia(f))
    {
        fila_u * aux = f;
    
        if(forOMesmoUtilizador(aux->atual,u))
        {
            f = aux->seguinte;
            free(aux);
            return f;
        }

        else
        {
            fila_u * aux_seguinte = aux->seguinte;
            
            while(!estiverNoFimDaFila(aux_seguinte))
            {
                if(forOMesmoUtilizador(aux_seguinte->atual,u))
                {
                   aux->seguinte = aux_seguinte->seguinte;
                   // comentado para não perder o utilizador
                   //free(aux_seguinte);
                   
                   return f;
                }
                else
                {
                    aux = aux_seguinte;
                    aux_seguinte = aux_seguinte->seguinte;
                }
            }

            aux->seguinte = NULL;
            // comentado para não perder o utilizador
            //free(aux_seguinte);
            return f;
        }
    }
}

fila_u * trocarFila(fila_u * f_orig,fila_u * f_dest,utilizador * u)
{
    f_orig = removerUtilizador(f_orig,u);
    inserirUtilizador(f_dest,u);    
}
    
            

utilizador * criarUtilizador()
{
    utilizador * u = alocaUtilizador();
    inicializarUtilizador(u);
    printf("Chegou o utilizador nº %i\n",u->id);
    return u;
}

fila_u * criarFila(utilizador * u)
{
    fila_u * f = alocaFila();
    f->atual = u;
    f->seguinte = NULL;
    return f;
}

void inicializarUtilizador(utilizador * u)
{
    nr_utilizadores++;
    u->id = nr_utilizadores;
    //u->tempo_entrada = time(NULL);
}

utilizador * alocaUtilizador()
{ 
    return (utilizador *) malloc(sizeof(utilizador)); 
}
fila_u * alocaFila()
{
    return (fila_u *) malloc(sizeof(fila_u));
}


int forOMesmoUtilizador(utilizador * u1,utilizador * u2) { return u1->id == u2->id; }
void colocarElementoNaFila(utilizador * u, fila_u * f) { f->atual = u; }
int filaEstaVazia(fila_u * f) { return !f->atual; }
int estiverNoFimDaFila(fila_u * f) { return !f->seguinte; }
