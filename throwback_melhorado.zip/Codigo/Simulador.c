#include "Header.h"
/***************************************************************************************************************************/
/**VARIÁVEIS GLOBAIS******************************************************************************************************/
/***************************************************************************************************************************/
socket_t s;
mutex_t m_comunicacao;
/**MODELO - GUICHÉ DE COMPRA************/
pthread_t guicheCompra;
mutex_t mGCP;
semaforo_t sGCP;
int nrPessoasEspGCP=0;
mutex_t mGCNP;
semaforo_t sGCNP;
int nrPessoasEspGCNP=0;
/*******************************************/
/**MODELO - GUICHÉ DE DEVOLUÇÃO*********/
pthread_t guicheDevolucao;
mutex_t mDev;
semaforo_t sClienteDev,sDev;
int nrPessoasEspDev = 0;
/***************************************************************************************************************************/
/**MAIN******************************************************************************************************/
/***************************************************************************************************************************/
int main()
{
	printf("@@@SIMULADOR@@@\n");
	printf("A configuração está a ser lida..\n");
	lerConfigSimulador(&sconf);
	Fechar(&m_nrUtilizadoresRestantes);
	nrUtilizadoresRestantes = sconf.max_pessoas_total;
	Abrir(&m_nrUtilizadoresRestantes);

	printf("A configuração foi lida com sucesso.\n");
	s = criarSocketCliente();
	printf("Conectou-se com sucesso ao Monitor.\n");
	srand(time(NULL));

	printf("---INÍCIO---\n");

	inicializarMutex(&mGCP);
	inicializarMutex(&mGCNP);
	inicializarSemaforo(&sGCNP,0);
	inicializarSemaforo(&sGCP,0);
	inicializarSemaforo(&sClienteDev,0);
	inicializarSemaforo(&sDev,0);

	int i;//Variável para ir incrementado até atingir o valor do delay, só aí é que a informação é enviada para evitar repetir.

	time_t start, end;
	time(&start); //Começou a simulação

	pthread_create(&guicheCompra,NULL,guicheCompraFunc,NULL);
	pthread_create(&guicheDevolucao,NULL,filaDev,NULL);

	while(nrUtilizadoresRestantes >0)
	{
		for(i=0;i<DELAY_ENTRE_ENVIOS;i++);
		if(podeCriarCliente())				//Verificamos se é para criar um cliente
		{
			criarCliente();
		}

		time(&end);
		tempoSimul=difftime(end, start);
	}

	hora = tempoSimul / 3600;      	//Para calcular o nr de horas
	minutosAux = tempoSimul / 60;	//Cálculo intermédio para os minutos
	minutos = minutosAux % 60;		//Para calcular os minutos
	segundos = tempoSimul % 60;		//Para calcular o número de segundos
	printf("Acabou o tempo de simulação: %d hora(s) %d minuto(s) %d segundo(s)\n",hora,minutos,segundos);

	Fechar(&m_comunicacao);
	escreverIntNoMonitor(FIM_SIMULACAO); //Avisa o Monitor que terminou a simulação
	escreverIntNoMonitor(nrUtilizadores);
	Abrir(&m_comunicacao);
	printf("---FIM---\n");
	getchar();
	return 0;
}

//Cliente entra para a fila do guiché com prioridades
void entraClienteGuicheCompraPrio(int id)
{
	Fechar(&mGCP);
	nrPessoasEspGCP++;
	printf("Número de clientes prioritários à espera no guiché: %d\n",nrPessoasEspGCP);
	Abrir(&mGCP);
	Esperar(&sGCP);
}

//Cliente entra para a fila do guiché sem prioridades
void entraClienteGuicheCompraNaoPrio(int id)
{
	Fechar(&mGCNP);
	nrPessoasEspGCNP++;
	printf("Número de clientes não prioritários à espera no guiché: %d\n",nrPessoasEspGCNP);
	Abrir(&mGCNP);
	Esperar(&sGCNP);
}

//Para controlar as duas filas (prio e não prio) para comprar o bilhete
void * guicheCompraFunc()
{
	int i;
	while(1)
	{
		for(i=0;i<DELAY_ENTRE_ENVIOS;i++);
		for(i=0;i<DELAY_ENTRE_ENVIOS;i++);
		for(i=0;i<DELAY_ENTRE_ENVIOS;i++);
		if(randWithProb(sconf.taxa_atendimento_compra))	//Para não vender bilhetes a todos 
		{
			Fechar(&mGCP);
			if(nrPessoasEspGCP>0)
			{
				nrPessoasEspGCP--;
				Abrir(&mGCP);
				Assinalar(&sGCP);
				printf("Foi assinalado o GCP\n");
			}
			else 
			{
				Abrir(&mGCP);
				Fechar(&mGCNP);
				if(nrPessoasEspGCNP>0)
				{
					nrPessoasEspGCNP--;
					Abrir(&mGCNP);
					Assinalar(&sGCNP);
					printf("Foi assinalado o GCNP\n");
				}
				else Abrir(&mGCNP);
			}
		}
	}
}

/***************************************************************************************************************************/
/**GUICHÉ DE DEVOLUÇÃO**************************************************************************************************/
/***************************************************************************************************************************/
void entraClienteDev()
{
	Fechar(&mDev);
	if(nrPessoasEspDev < sconf.max_pessoas_dev)
	{
		nrPessoasEspDev++;
		Abrir(&mDev);
		Assinalar(&sClienteDev);	//Assinalar que já existe clientes a espera.Inicializado a 0.
		Esperar(&sDev);
	}
	else
	{
		Abrir(&mDev);
	}
}
void * filaDev()
{
	int i;
	while(1)
	{
		for(i=0;i<DELAY_ENTRE_ENVIOS;i++);
		for(i=0;i<DELAY_ENTRE_ENVIOS;i++);
		for(i=0;i<DELAY_ENTRE_ENVIOS;i++);
		if(randWithProb(sconf.taxa_atendimento_dev))	//Para não vender bilhetes a todos 
		{
			Esperar(&sClienteDev);

			Fechar(&mDev);
			nrPessoasEspDev--;
			Abrir(&mDev);

			Assinalar(&sDev);
		}
	}
}

int veSeDesiste()
{
	if(randWithProb(sconf.prob_desistencia))
	{
		entraClienteDev();
		return CLIENTE_DESISTE;
	}
	else
	{
		return CLIENTE_NAO_DESISTE;
	}
}
/***************************************************************************************************************************/
/**FUNÇÕES AUXILIARES*****************************************************************************************************/
/***************************************************************************************************************************/
void escreverNoMonitor(char message[])
{
	write(s,message,BUFFER_SIZE);
}
void escreverIntNoMonitor(int x)
{
	char message[BUFFER_SIZE];
	sprintf(message,"%i",x);
	escreverNoMonitor(message);
}
//Função gerar se é para criar um cliente ou não
int podeCriarCliente()
{
	int permissao= randWithProb(sconf.prob_chegar_pessoas);
	if(permissao && nrUtilizadores < sconf.max_pessoas_total)
	{
		return CLIENTE_E_CRIADO;
	}
	else
	{
		return CLIENTE_NAO_E_CRIADO;
	}
}

//Função para criar a tarefa do clientes
void criarCliente()
{
		Fechar(&m_nrUtilizadores);
		nrUtilizadores++;
		Abrir(&m_nrUtilizadores);

		pthread_t cliente;
		pthread_create(&cliente,NULL,cliente_act,(void *)(intptr_t)(randWithProb(0.5)));
}

//Função que vai controlar as ações dos clientes
void * cliente_act(void *prio)
{
	time_t tempoChegadaG,TempoSaidaG;
	utilizador c;
	Fechar(&m_nrUtilizadores);
	c.id=nrUtilizadores;
	Abrir(&m_nrUtilizadores);
	c.prioritarios=(int *)prio;
	c.estado=0;
	c.tempoEspGuiche=0;
	c.tempoEspCarros=0;
	c.emViagem=0;

	char log[BUFFER_SIZE];
	sprintf(log,"Chegou o cliente com o id %d e prioridade %d\n",c.id,(int)(intptr_t)c.prioritarios);
	printf("%s",log);
	escreverNoLog(log);

	if(c.prioritarios)
	{
		time(&tempoChegadaG);
		entraClienteGuicheCompraPrio(c.id);
		time(&TempoSaidaG);
		c.tempoEspGuiche=difftime(TempoSaidaG, tempoChegadaG);

		Fechar(&m_comunicacao);
		escreverIntNoMonitor(COMPRA_BILHETE);
		escreverIntNoMonitor(c.id);
		escreverIntNoMonitor(c.tempoEspGuiche);
		Abrir(&m_comunicacao);

		Fechar(&m_nrUtilizadoresRestantes);
		nrUtilizadoresRestantes--;
		Abrir(&m_nrUtilizadoresRestantes);

		if(veSeDesiste())
		{
			Fechar(&m_nrDesistencias);
			nrDesistencias++;
			Abrir(&m_nrDesistencias);
			
			Fechar(&m_comunicacao);
			escreverIntNoMonitor(DESISTENCIA);
			escreverIntNoMonitor(c.id);
			escreverIntNoMonitor(nrDesistencias);
			Abrir(&m_comunicacao);
		}
	}
	else
	{
		time(&tempoChegadaG);
		entraClienteGuicheCompraNaoPrio(c.id);
		time(&TempoSaidaG);
		c.tempoEspGuiche=difftime(TempoSaidaG, tempoChegadaG);

		Fechar(&m_comunicacao);
		escreverIntNoMonitor(COMPRA_BILHETE);
		escreverIntNoMonitor(c.id);
		escreverIntNoMonitor(c.tempoEspGuiche);
		Abrir(&m_comunicacao);

		Fechar(&m_nrUtilizadoresRestantes);
		nrUtilizadoresRestantes--;
		Abrir(&m_nrUtilizadoresRestantes);

		if(veSeDesiste())
		{	
			Fechar(&m_nrDesistencias);
			nrDesistencias++;
			Abrir(&m_nrDesistencias);
			
			Fechar(&m_comunicacao);
			escreverIntNoMonitor(DESISTENCIA);
			escreverIntNoMonitor(c.id);
			escreverIntNoMonitor(nrDesistencias);
			Abrir(&m_comunicacao);
		}
	}
}
