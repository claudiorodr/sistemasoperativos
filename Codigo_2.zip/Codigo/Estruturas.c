#include "Estruturas.h"

fila_u * inserirUtilizador(fila_u * f, utilizador * u)
{ 
    fila_u * aux = f;
    fila_u * aux2 = aux;
    fila_u * aux_u = alocaFila();
    aux_u->atual = u;
    aux_u->seguinte = NULL;

    if(!aux->atual) { aux->atual = u; }
    
    else
    {
        while(aux2->seguinte) 
        { aux2 = aux2->seguinte; }
            
        aux2->seguinte = aux_u;
    }

    return aux;
}

utilizador * alocaUtilizador()
{ 
    return (utilizador *) malloc(sizeof(utilizador)); 
}

fila_u * alocaFila()
{
    return (fila_u *) malloc(sizeof(fila_u));
}
