#include "Monitor.h"


void * criarThreadUtilizador()
{
    pthread_t t;
    pthread_create(&t,NULL,(void *)criarUtilizador,NULL);  
}

utilizador * inicializarUtilizador(utilizador * u)
{
    nr_utilizadores++;
    u->id = nr_utilizadores;
    u->tempo_entrada = time(NULL);
    return u;
}

utilizador * criarUtilizador()
{
    utilizador * u = alocaUtilizador();
    u = inicializarUtilizador(u);
    return u;
}

void main()
{
    fila_u * f_recbil = alocaFila();
    f_recbil->atual = NULL;
    f_recbil->seguinte = NULL;
    
    fila_u * f_monrussa = alocaFila();

    utilizador * u = criarUtilizador();
    printf("%i\n",u->id);
    
    inserirUtilizador(f_recbil,u);
    
    printf("%i\n",f_recbil->atual->id);
}
