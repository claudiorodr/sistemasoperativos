#ifndef ESTRUTURAS_H
#define ESTRUTURAS_H

#include <time.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include "Restricoes.h"

typedef struct utilizador
{
    unsigned int id;
    time_t tempo_entrada;
    time_t tempo_saida;
    unsigned int razao_saida;
} utilizador;

typedef struct fila_u
{
    utilizador * atual;
    struct fila_u * seguinte;
} fila_u;

fila_u * inserirUtilizador(fila_u * f, utilizador * u);
utilizador * alocaUtilizador();
fila_u * alocaFila();

#endif
