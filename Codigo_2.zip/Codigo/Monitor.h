#ifndef MONITOR_H
#define MONITOR_H

#include <time.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include "Restricoes.h"
#include "Estruturas.h"

unsigned int nr_utilizadores = 0;
time_t tempo_inicio;

utilizador * inicializarUtilizador(utilizador * u);
void * criarThreadUtilizador();
utilizador * criarUtilizador();

#endif
