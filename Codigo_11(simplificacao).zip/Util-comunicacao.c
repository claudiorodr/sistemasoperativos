#include "Header.h"

socket_t criarSocket()
{
	return socket(AF_UNIX,SOCK_STREAM,0);
}

sockaddr_un criarLigacaoSocket()
{
	sockaddr_un socket_addr;

	socket_addr.sun_family=AF_UNIX;
	strcpy(socket_addr.sun_path,UNIXSTR_PATH);

	return socket_addr;
}

socket_t criarSocketCliente()
{
	socket_t s = criarSocket();
	sockaddr_un s_addr = criarLigacaoSocket();
	connect(s,(sockaddr*) &s_addr,sizeof(sockaddr_un));

	return s;
}

client_t esperarPorCliente()
{
	socket_t s = criarSocket();
	sockaddr_un s_addr = criarLigacaoSocket();
	unlink(UNIXSTR_PATH);

	bind(s,(sockaddr*) &s_addr,sizeof(sockaddr_un));
	listen(s,1);

	sockaddr_un client_addr;

	int clientlen = sizeof(client_addr);
	client_t client;

	printf("À espera de clientes...\n");
	client = accept(s,(sockaddr*) &client_addr,&clientlen);	// Quando vierem, aceita clientes
	printf("Chegou alguem\n");

	return client;
}
