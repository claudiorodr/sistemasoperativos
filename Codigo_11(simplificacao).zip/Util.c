#include "Header.h"

/* Semáforo */
void inicializarSemaforo(semaforo_t * sem, int v)
{
	sem_init(sem,0,v);
}

void Esperar(semaforo_t * sem)
{
	sem_wait(sem);
}
void Assinalar(semaforo_t * sem)
{
	sem_post(sem);
}
void destruirSemaforo(semaforo_t * sem)
{
	sem_destroy(sem);
}

/* Trinco */
void inicializarMutex(trinco_t * mutex) 
{ 
	pthread_mutex_init(mutex,NULL); 
}
void Fechar(trinco_t * mutex)
{ 
	pthread_mutex_lock(mutex); 
}
void Abrir(trinco_t * mutex)
{ 
	pthread_mutex_unlock(mutex); 
}
void destruirMutex(trinco_t * mutex)
{
	pthread_mutex_destroy(mutex);
}

/* Tarefas */
void atribuirFuncaoATarefa(void * funcao, tarefa_t t) 
{ 
	int error = pthread_create(&t,NULL,funcao,NULL); 
	if(error)
	{
		printf("Erro ao criar uma tarefa.\n");
		exit(1);
	}
}
