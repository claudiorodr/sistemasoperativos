#include "Header.h"
client_t client;

/********/
/* MAIN */
/********/
int main()
{
	printf("@@@MONITOR@@@\n");

	client = esperarPorCliente();

	int outputSimulador;
	while(FOREVER)
	{
		outputSimulador = lerIntDoCliente();
		printf("O simulador mandou:%i\n",outputSimulador);			// Mostra o número

		//tratamento de dados do atoi(message)
	}

	return 0;
}


/************************/
/* FUNÇÕES AUXILIARES */
/************************/
int lerIntDoCliente()
{
	char message[BUFFER_SIZE];
	read(client,message,BUFFER_SIZE);
	return atoi(message);
}
