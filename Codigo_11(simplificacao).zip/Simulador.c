#include "Header.h"
socket_t s;

/********/
/* MAIN */
/********/
int main()
{
	printf("@@@SIMULADOR@@@\n");
	
	s = criarSocketCliente();
	
	printf("Conectou-se ao servidor.\n");

	int x = 0;

	while(FOREVER)
	{
		//gera números
		// ...
		escreverIntNoMonitor(x); //manda para o monitor
		x++;
	}


	return 0;
}



/************************/
/* FUNÇÕES AUXILIARES */
/************************/
void escreverNoMonitor(char message[])
{
	write(s,message,BUFFER_SIZE);
}
void escreverIntNoMonitor(int x)
{
	char message[BUFFER_SIZE];
	sprintf(message,"%i",x);
	escreverNoMonitor(message);
}
