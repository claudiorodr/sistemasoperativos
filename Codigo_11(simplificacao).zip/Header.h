#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <pthread.h>
#include <unistd.h>
#include <semaphore.h>

#define UNIXSTR_PATH "/tmp/s.unixstr"
#define UNIXDG_PATH  "/tmp/s.unixdgx"
#define UNIXDG_TMP   "/tmp/dgXXXXXXX"

#define FOREVER 1
#define BUFFER_SIZE 255

typedef int socket_t;
typedef int client_t;
typedef struct sockaddr_un sockaddr_un;
typedef struct sockaddr sockaddr;
typedef pthread_mutex_t trinco_t;
typedef pthread_t tarefa_t;
typedef sem_t semaforo_t;

/* Semáforo */
void inicializarSemaforo(semaforo_t * sem, int v);
void Esperar(semaforo_t * sem);
void Assinalar(semaforo_t * sem);
void destruirSemaforo(semaforo_t * sem);

/* Trinco */
void inicializarMutex(trinco_t * mutex);
void Fechar(trinco_t * mutex);
void Abrir(trinco_t * mutex);
void destruirMutex(trinco_t * mutex);

/* Tarefas */
void atribuirFuncaoATarefa(void * funcao, tarefa_t t);

/* Comunicação */
socket_t criarSocket();
sockaddr_un criarLigacaoSocket();
socket_t criarSocketCliente();
client_t esperarPorCliente();

/*	MONITOR		*/
int lerIntDoCliente();



/*				*/

/*	SIMULADOR	*/
void escreverNoMonitor(char message[]);
void escreverIntNoMonitor(int x);



/*				*/
