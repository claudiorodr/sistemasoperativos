#include "Header.h"
/***************************************************************************************************************************/
/**VARIÁVEIS GLOBAIS******************************************************************************************************/
/***************************************************************************************************************************/
client_t simulador;
mutex_t mMonitor;
/***************************************************************************************************************************/
/**MAIN********************************************************************************************************************/
/***************************************************************************************************************************/
int main()
{
	printf("@@@MONITOR@@@\n");
	printf("A configuração está a ser lida..\n");
	lerConfigMonitor(&mconf);
	printf("A configuração foi lida com sucesso.\n");
	printf("À espera do simulador..\n");
	simulador = esperarPorCliente();
	printf("O simulador foi conectado com sucesso.\n");
	printf("---INÍCIO---\n");

	int terminar=0;
	while(!terminar)
	{
		converteMens(&terminar,lerDoSimulador());
	}

	char log[BUFFER_SIZE];
	sprintf(log,"Tempo médio de espera na fila do guiché de compra: %.2f segundos\n",tempoMedEspG); //falta rever, tá meio aldrabado (fica o dobro ou metade ou wtv)
	printf("%s",log);
	escreverNoLog(log);

	sprintf(log,"Número de desistências: %d\n",nrDesistencias);
	printf("%s",log);
	escreverNoLog(log);

	printf("---FIM---\n");
	getchar();
	return 0;
}
void converteMens(int *terminar,char mensagem[])
{
	int id,tempEspG;
	int evento = mensagem[0] - 48;
	char log[BUFFER_SIZE];
	switch (evento)
	{
		//Caso seja para terminar a simulação
		case FIM_SIMULACAO:
			tempoMedEspG/=lerIntDoSimulador(); //vai dividir pelo número de utilizadores
			*terminar=1;
			break;
		//Caso venha só o id
		case COMPRA_BILHETE:
			id=lerIntDoSimulador();
			tempEspG=lerIntDoSimulador();
			tempoMedEspG+=tempEspG;
			sprintf(log,"O cliente %d comprou o bilhete (esperou na fila %d segundos)\n",id,tempEspG);
			printf("%s",log);
			escreverNoLog(log);
			break;
		//Caso alguém desista
		case DESISTENCIA:
			id=lerIntDoSimulador();
			nrDesistencias=lerIntDoSimulador();
			sprintf(log,"O cliente %d mudou de ideias e foi para a guiché de devolução\n",id);
			printf("%s",log);
			escreverNoLog(log);
			break;
	}
}
/***************************************************************************************************************************/
/**FUNÇÕES AUXILIARES*****************************************************************************************************/
/***************************************************************************************************************************/
char* lerDoSimulador()
{
	char * mensagem = (char *) malloc(sizeof(char)*BUFFER_SIZE);
	read(simulador,mensagem,BUFFER_SIZE);
	return mensagem;
}
int lerIntDoSimulador()
{
	return atoi(lerDoSimulador());
}
