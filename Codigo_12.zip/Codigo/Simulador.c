#include "Header.h"

/***************************************************************************************************************************/
/**VARIÁVEIS GLOBAIS******************************************************************************************************/
/***************************************************************************************************************************/
socket_t s;
mutex_t mSimulador;
FILE * file;

mutex_t mGCP,mGCNP;
semaforo_t semGCP,semGCNP;
pthread_t guicheCompra;
int nrPessoasEspGCP=0;
int nrPessoasEspGCNP=0;

/***************************************************************************************************************************/
/**MAIN******************************************************************************************************/
/***************************************************************************************************************************/
int main()
{
	printf("@@@SIMULADOR@@@\n");

	printf("A configuração está a ser lida..\n");
	lerConfigSimulador(&sconf);
	nrUtilizadoresRestantes = sconf.max_pessoas;
	printf("A configuração foi lida com sucesso.\n");

	s = criarSocketCliente();
	printf("Conectou-se com sucesso ao Monitor.\n");

	printf("---INÍCIO---\n");

	inicializarMutex(&mSimulador);
	inicializarMutex(&mGCP);
	inicializarMutex(&mGCNP);
	inicializarSemaforo(&semGCNP,0);
	inicializarSemaforo(&semGCP,0);

	srand(time(NULL));

	int contador = 0;//Variável para ir incrementado até atingir o valor do delay, só aí é que a informação é enviada para evitar repetir.
	int clienteBool = 0;	//Variável para saber se é para criar um cliente ou não

	time_t start, end;
	time(&start); //Começou a simulação

	while(nrUtilizadoresRestantes > 0)
	{
		// (...)
		// geração de números (consoante a configuração - probabilidades e etc)
		// (...)		


		if(contador == DELAY_ENTRE_ENVIOS)				//Delay usado para não mostrar o mesmo cliente várias vezes
		{
			clienteBool = podeCriarCliente();		//Guardamos o o bool enviado do simulador para saber se é para criar cliente
			//escreverIntNoMonitor(clienteBool);	//Escrevemos no monitor se foi criado um cliente
			contador = 0;	

			if(clienteBool)				//Verificamos se é para criar um cliente
			{
				criarCliente();
			}

			if(!(rand() % 3))	//Para não vender bilhetes a todos 
			{
				pthread_create(&guicheCompra,NULL,guicheCompraFunc,NULL);
			}			
		}
		
		contador++;


		time(&end);
		tempoSimul=difftime(end, start);
		
	}

	hora = tempoSimul / 3600;      	//Para calcular o nr de horas
	minutosAux = tempoSimul / 60;	//Cálculo intermédio para os minutos
	minutos = minutosAux % 60;		//Para calcular os minutos
	segundos = tempoSimul % 60;		//Para calcular o número de segundos
	printf("Acabou o tempo de simulação: %d hora(s) %d minuto(s) %d segundo(s)\n",hora,minutos,segundos);

	printf("---FIM---\n");

	escreverIntNoMonitor(-1); //Avisa o Monitor que terminou a simulação

	getchar();
	
	return 0;
}

/***************************************************************************************************************************/
/**FUNÇÕES AUXILIARES*****************************************************************************************************/
/***************************************************************************************************************************/
void escreverNoMonitor(char message[])
{
	write(s,message,BUFFER_SIZE);
}
void escreverIntNoMonitor(int x)
{
	char message[BUFFER_SIZE];
	sprintf(message,"%i",x);
	escreverNoMonitor(message);
}
//Função gerar se é para criar um cliente ou não
int podeCriarCliente()
{
	int permissao = rand() % sconf.prob_chegar_pessoas;
	if(permissao == 0 && nrUtilizadores < sconf.max_pessoas)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

//Função para criar a tarefa do clientes
void criarCliente()
{
		Fechar(&mSimulador);
		nrUtilizadores++;
		Abrir(&mSimulador);

		pthread_t cliente;
		pthread_create(&cliente,NULL,cliente_act,(void *)(intptr_t)(rand()%2));
}

//Função que vai controlar as ações dos clientes
void * cliente_act(void *prio)
{
	Fechar(&mSimulador);
	utilizador c;
	c.id=nrUtilizadores;
	c.prioritarios=(int *)prio;
	c.estado=0;
	c.tempoEspGuiche=0;
	c.tempoEspCarros=0;
	c.emViagem=0;
	Abrir(&mSimulador);

	char * message = (char *) malloc(sizeof(char *) * BUFFER_SIZE);
	bzero(message,sizeof(message));
	sprintf(message,"Chegou o cliente com o id %d e prioridade %d",c.id,(int)(intptr_t)c.prioritarios);
	printf("%s\n",message);
	escreverNoLog(message);
	free(message);

	Fechar(&mSimulador);
	if(c.prioritarios)
	{
		Abrir(&mSimulador);
		entraClienteGuicheCompraPrio(c.id);
	}
	else
	{
		Abrir(&mSimulador);
		entraClienteGuicheCompraNaoPrio(c.id);
	}
	Abrir(&mSimulador);

	// (...)
}
void escreverNoLog(char message[])
{
	file = fopen(FICHEIRO_LOG,APPEND_MODE);
	fprintf(file,"%s\n",message);
	fclose(file);
}

//Cliente entra para a fila do guiché com prioridades
void entraClienteGuicheCompraPrio(int id)
{
	Fechar(&mGCP);
	nrPessoasEspGCP++;
	printf("Número de clientes prioritários à espera no guiché: %d\n",nrPessoasEspGCP);
	Abrir(&mGCP);
	Esperar(&semGCP);
	Fechar(&mGCP);
	nrPessoasEspGCP--;
	nrUtilizadoresRestantes--;
	//printf("O cliente %d comprou o bilhete\n",id);
	escreverIntNoMonitor(id);
	Abrir(&mGCP);
}

//Cliente entra para a fila do guiché sem prioridades
void entraClienteGuicheCompraNaoPrio(int id)
{
	Fechar(&mGCNP);
	nrPessoasEspGCNP++;
	printf("Número de clientes não prioritários à espera no guiché: %d\n",nrPessoasEspGCNP);
	Abrir(&mGCNP);
	Esperar(&semGCNP);
	Fechar(&mGCNP);
	nrPessoasEspGCNP--;
	nrUtilizadoresRestantes--;
	//printf("O cliente %d comprou o bilhete\n",id);
	escreverIntNoMonitor(id);
	Abrir(&mGCNP);
}

//Para controlar as duas filas (prio e não prio) para comprar o bilhete
void * guicheCompraFunc()
{
	Fechar(&mGCP);
	if(nrPessoasEspGCP>0)
	{
		Abrir(&mGCP);
		Assinalar(&semGCP);
		printf("Foi assinalado o GCP\n");
		//servico();

	}
	else 
	{
		Abrir(&mGCP);
		Fechar(&mGCNP);
		if(nrPessoasEspGCNP>0)
		{
			Abrir(&mGCNP);
			Assinalar(&semGCNP);
			//servico();
		}
	}
		Abrir(&mGCP);
		Abrir(&mGCNP);
}


