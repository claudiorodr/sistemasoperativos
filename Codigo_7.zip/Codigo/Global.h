#ifndef GLOBAL_H
#define GLOBAL_H

// Variáveis globais
static int nr_utilizadores = 0;

// Limites
#define MAX_UTILIZADORES_CARRO 50
#define MAX_UTILIZADORES_FILA 100

// Viagem de montanha-russa
#define TEMPO_VIAGEM_MIN 10

// Tempos gastos pelo utilizador
#define TEMPO_UTILIZADOR_ENTRADA_CARRO 2
#define TEMPO_UTILIZADOR_SAIDA_CARRO 2 

#endif
