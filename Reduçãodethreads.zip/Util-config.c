#include "Header.h"
/************************************************************************************************************/
/**LEITURA DO FICHEIRO DE CONFIGURAÇÃO DO MONITOR******************************************************/
/***************************/
void lerConfigMonitor(monitor_config * conf)
{
	FILE * fp = fopen(FICHEIRO_MONITOR_CONFIG,"r+");

	//conf->t_viagem = DEFAULT_T_VIAGEM;
	//conf->max_pessoas = DEFAULT_MAX_PESSOAS_TOTAL;

	char buffer[BUFFER_SIZE];
	char param[BUFFER_SIZE];
	char value[BUFFER_SIZE];

	int i;

	while(fgets(buffer,BUFFER_SIZE,fp))
	{
		for(i = 0 ; buffer[i] != '=' ; i++);
	
		bzero(param,sizeof(param));
		bzero(value,sizeof(value));

		strncpy(param,buffer,i);	
		strncpy(value,buffer+i+1,strlen(buffer)-i-1);

		if(strequals(param,"t_viagem"))
		{
			conf->t_viagem = atoi(value); 
		}
		else
		{
		if(strequals(param,"max_pessoas"))
		{
			conf->max_pessoas = atoi(value);
		}
		else
		{
			//...
		}
		}

		bzero(param,sizeof(param));
		bzero(value,sizeof(value));
		bzero(buffer,sizeof(buffer));
	}
}
/************************************************************************************************************/
/**LEITURA DO FICHEIRO DE CONFIGURAÇÃO DO SIMULADOR***************************************************/
/****************************************************************/
void lerConfigSimulador(simulador_config * conf)
{
	FILE * fp = fopen(FICHEIRO_SIMULADOR_CONFIG,"r+");

	conf->prob_chegar_pessoas = DEFAULT_PROB_CHEGAR_PESSOAS;
	conf->duracao_viagem = DEFAULT_DURACAO_VIAGEM;
	conf->max_pessoas_total = DEFAULT_MAX_PESSOAS_TOTAL;
	conf->taxa_atendimento_compra = DEFAULT_TAXA_ATENDIMENTO_COMPRA;
	conf->taxa_atendimento_dev = DEFAULT_TAXA_ATENDIMENTO_DEV;
	conf->taxa_atendimento_carros = DEFAULT_TAXA_ATENDIMENTO_CARROS;
	conf->max_pessoas_dev = DEFAULT_MAX_PESSOAS_DEV;
	conf->prob_desistencia = DEFAULT_PROB_DESISTENCIA;

	char buffer[BUFFER_SIZE];
	char param[BUFFER_SIZE];
	char value[BUFFER_SIZE];

	int i;

	while(fgets(buffer,BUFFER_SIZE,fp))
	{
		for(i = 0 ; buffer[i] != '=' ; i++);
	
		bzero(param,sizeof(param));
		bzero(value,sizeof(value));

		strncpy(param,buffer,i);	
		strncpy(value,buffer+i+1,strlen(buffer)-i-1);

		if(strequals(param,"prob_chegar_pessoas"))
		{
			conf->prob_chegar_pessoas = atoi(value); 
		}
		else
		{
		if(strequals(param,"duracao_viagem"))
		{
			conf->duracao_viagem = atoi(value); 
		}
		else
		{
		if(strequals(param,"max_pessoas_total"))
		{
			conf->max_pessoas_total = atoi(value);
		}
		else
		{
		if(strequals(param,"taxa_atendimento_compra"))
		{
			conf->taxa_atendimento_compra = atoi(value);
		}
		else
		{
		if(strequals(param,"taxa_atendimento_dev"))
		{
			conf->taxa_atendimento_dev = atoi(value);
		}
		else
		{
		if(strequals(param,"taxa_atendimento_carros"))
		{
			conf->taxa_atendimento_carros = atoi(value);
		}
		else
		{
		if(strequals(param,"max_pessoas_dev"))
		{
			conf->max_pessoas_dev = atoi(value);
		}
		else
		{
		if(strequals(param,"prob_desistencia"))
		{
			conf->prob_desistencia = atoi(value);
		}
		else
		{
		}
		}
		}
		}
		}
		}
		}
		}

		bzero(param,sizeof(param));
		bzero(value,sizeof(value));
		bzero(buffer,sizeof(buffer));
	}

}
