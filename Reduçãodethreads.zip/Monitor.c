#include "Header.h"
/***************************************************************************************************************************/
/**VARIÁVEIS GLOBAIS******************************************************************************************************/
/***************************************************************************************************************************/
client_t simulador;
mutex_t mMonitor;
/***************************************************************************************************************************/
/**MAIN********************************************************************************************************************/
/***************************************************************************************************************************/
int main()
{
	printf("@@@MONITOR@@@\n");
	printf("A configuração está a ser lida..\n");
	lerConfigMonitor(&mconf);
	printf("A configuração foi lida com sucesso.\n");
	printf("À espera do simulador..\n");
	simulador = esperarPorCliente();
	printf("O simulador foi conectado com sucesso.\n");
	printf("---INÍCIO---\n");

	int terminar=0;
	while(!terminar)
	{
		converteMens(&terminar,lerDoSimulador());

		// (...)
		// tratamento de dados (do outputSimulador)
		// (...)
		// conversão numa mensagem (ex.: usado para o log)
		// (...)

		//escreverNoLog("lá vai uma");
	}
	char log[BUFFER_SIZE];

	sprintf(log,"Tempo médio de espera na fila do guiché: %.2f segundos\n",tempoMedEspG); //falta rever, tá meio aldrabado (fica o dobro ou metade ou wtv)
	printf("%s",log);
	escreverNoLog(log);

	if(nrDesistencias!=0)
	{
		printf("O tempo de espera médio de espera na fila das devoluções %.2f segundos\n",tempoMedEspDev/nrDesistencias);
	}
	else
	{
		printf("O tempo médio na fila de espera das devoluções foi 0 segundos pois ninguém desistiu\n");
	}

	printf("Número de desistências: %d\n\n",nrDesistencias);
	printf("Número de viagens efetuadas: %d\n",nrViagens);

	sprintf(log,"Número de desistências: %d\n",nrDesistencias);
	printf("%s",log);
	escreverNoLog(log);

	printf("---FIM---\n");
	getchar();
	return 0;
}
/***************************************************************************************************************************/
/**FUNÇÕES AUXILIARES*****************************************************************************************************/
/***************************************************************************************************************************/
char* lerDoSimulador()
{
	char * mensagem = (char *) malloc(sizeof(char)*BUFFER_SIZE);
	read(simulador,mensagem,BUFFER_SIZE);
	return mensagem;
}
int lerIntDoSimulador()
{
	return atoi(lerDoSimulador());
}
void converteMens(int *terminar,char mensagem[])
{
	int id,tempEspG,tempEspDev,NrViagens;
	int evento = mensagem[0] - 48;
	char log[BUFFER_SIZE];
	switch (evento)
	{
		//Caso seja para terminar a simulação
		case FIM_SIMULACAO:
			tempoMedEspG/=lerIntDoSimulador(); //vai dividir pelo número de utilizadores
			*terminar=1;
			break;
		//Caso venha só o id
		case COMPRA_BILHETE:
			id=lerIntDoSimulador();
			tempEspG=lerIntDoSimulador();
			tempoMedEspG+=tempEspG;
			sprintf(log,"O cliente %d comprou o bilhete (demorou %d segundos)\n",id,tempEspG);
			printf("%s",log);
			escreverNoLog(log);
			break;
		//Caso alguém desista
		case DESISTENCIA:
			id=lerIntDoSimulador();
			nrDesistencias=lerIntDoSimulador();
			tempEspDev=atoi(lerDoSimulador());
			tempoMedEspDev+=tempEspDev;
			sprintf(log,"O cliente %d desistiu e foi para a guiché de devolução\n",id);
			printf("%s",log);
			escreverNoLog(log);
			break;
		case ENVIO_NR_VIAGENS:
			nrViagens=lerIntDoSimulador();
			break;
			
	}
}
