#include "Estruturas.h"

void inserirUtilizador(fila_u * f, utilizador * u)
{ 
    if(estaVazia(f)) { colocarElementoNaFila(u,f); }

    else
    {
        fila_u * aux = f;
        
        while(!estiverNoFimDaFila(aux)) 
            passaParaOProximoElemento(aux);
            
        fila_u * aux_u = criarFila(u);

        aux->seguinte = aux_u;
    }
}

utilizador * criarUtilizador()
{
    utilizador * u = alocaUtilizador();
    inicializarUtilizador(u);
    return u;
}

fila_u * criarFila(utilizador * u)
{
    fila_u * f = alocaFila();
    f->atual = u;
    f->seguinte = NULL;
    return f;
}

void inicializarUtilizador(utilizador * u)
{
    nr_utilizadores++;
    u->id = nr_utilizadores;
    u->tempo_entrada = time(NULL);
}

utilizador * alocaUtilizador()
{ 
    return (utilizador *) malloc(sizeof(utilizador)); 
}
fila_u * alocaFila()
{
    return (fila_u *) malloc(sizeof(fila_u));
}

void passaParaOProximoElemento(fila_u * f) { f=f->seguinte; }
void colocarElementoNaFila(utilizador * u, fila_u * f) { f->atual = u; }
int estaVazia(fila_u * f) { return !f->atual; }
int estiverNoFimDaFila(fila_u * f) { return !f->seguinte; }
