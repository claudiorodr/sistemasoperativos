#include "Header.h"

void lerConfigMonitor(monitor_config * conf)
{
	FILE * fp = fopen(FICHEIRO_MONITOR_CONFIG,"r+");

	conf->t_viagem = DEFAULT_T_VIAGEM;
	conf->max_pessoas = DEFAULT_MAX_PESSOAS;

	char buffer[BUFFER_SIZE];
	char param[BUFFER_SIZE];
	char value[BUFFER_SIZE];

	int i;

	while(fgets(buffer,BUFFER_SIZE,fp))
	{
		for(i = 0 ; buffer[i] != '=' ; i++);
	
		bzero(param,sizeof(param));
		bzero(value,sizeof(value));

		strncpy(param,buffer,i);	
		strncpy(value,buffer+i+1,strlen(buffer)-i-1);

		if(strequals(param,"t_viagem"))
		{
			conf->t_viagem = atoi(value); 
		}
		else
		{
		if(strequals(param,"max_pessoas"))
		{
			conf->max_pessoas = atoi(value);
		}
		else
		{
			//...
		}
		}

		bzero(param,sizeof(param));
		bzero(value,sizeof(value));
		bzero(buffer,sizeof(buffer));
	}
}

void lerConfigSimulador(simulador_config * conf)
{
	FILE * fp = fopen(FICHEIRO_SIMULADOR_CONFIG,"r+");

	conf->prob_chegar_pessoas = DEFAULT_PROB_CHEGAR_PESSOAS;

	char buffer[BUFFER_SIZE];
	char param[BUFFER_SIZE];
	char value[BUFFER_SIZE];

	int i;

	while(fgets(buffer,BUFFER_SIZE,fp))
	{
		for(i = 0 ; buffer[i] != '=' ; i++);
	
		bzero(param,sizeof(param));
		bzero(value,sizeof(value));

		strncpy(param,buffer,i);	
		strncpy(value,buffer+i+1,strlen(buffer)-i-1);

		if(strequals(param,"prob_chegar_pessoas"))
		{
			conf->prob_chegar_pessoas = atoi(value); 
		}
		else
		{
		if(strequals(param,"t_simulacao"))
		{
			conf->t_simulacao = atoi(value);		
			// (...)
		}
		else
		{
		if(strequals(param,"t_viagem"))
		{
			conf->t_viagem = atoi(value); 
		}
		else
		{
		if(strequals(param,"max_pessoas"))
		{
			conf->max_pessoas = atoi(value);
		}
		}
		}
		}

		bzero(param,sizeof(param));
		bzero(value,sizeof(value));
		bzero(buffer,sizeof(buffer));
	}

}
