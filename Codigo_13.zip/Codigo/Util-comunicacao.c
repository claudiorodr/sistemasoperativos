#include "Header.h"

/*****************************************************************************************************************/
/**COMUNICACAO (geral)*****************************************************************************************/
/*****************************************************************************************************************/
socket_t criarSocket()
{
	socket_t s = socket(AF_UNIX,SOCK_STREAM,0);
	verificarErro(s);

	return s;
}
sockaddr_un criarLigacaoSocket()
{
	sockaddr_un socket_addr;

	socket_addr.sun_family=AF_UNIX;
	strcpy(socket_addr.sun_path,UNIXSTR_PATH);

	return socket_addr;
}

/*****************************************************************************************************************/
/**SIMULADOR (cliente)*******************************************************************************************/
/*****************************************************************************************************************/
socket_t criarSocketCliente()
{
	socket_t s = criarSocket();
	sockaddr_un s_addr = criarLigacaoSocket();
	
	int connectstate = connect(s,(sockaddr*) &s_addr,sizeof(sockaddr_un));
	verificarErro(connectstate);

	return s;
}

/*****************************************************************************************************************/
/**MONITOR******************************************************************************************************/
/*****************************************************************************************************************/
client_t esperarPorCliente()
{
	socket_t s = criarSocket();
	sockaddr_un s_addr = criarLigacaoSocket();
	unlink(UNIXSTR_PATH);

	int bindstate = bind(s,(sockaddr*) &s_addr,sizeof(sockaddr_un));
	verificarErro(bindstate);
	
	int listenstate = listen(s,1);
	verificarErro(listenstate);

	sockaddr_un client_addr;

	int clientlen = sizeof(client_addr);
	client_t client;

	client = accept(s,(sockaddr*) &client_addr,&clientlen);	// Quando vierem, aceita clientes
	verificarErro(client);

	return client;
}
