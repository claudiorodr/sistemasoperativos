/**BIBLIOTECAS*************************************************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <pthread.h>
#include <unistd.h>
#include <semaphore.h>
#include <math.h>
/***************************************************************************************************************************/

/**CONSTANTES PARA SOCKETS**********************************************************************************************/
#define UNIXSTR_PATH "/tmp/s.unixstr"
#define UNIXDG_PATH  "/tmp/s.unixdgx"
#define UNIXDG_TMP   "/tmp/dgXXXXXXX"
/***************************************************************************************************************************/

/**CONSTANTES GERAIS*****************************************************************************************************/
#define FOREVER 1
#define BUFFER_SIZE 255

#define DELAY_ENTRE_ENVIOS 90000000

#define ERROR -1

#define APPEND_MODE "a"
#define FICHEIRO_LOG "log.log"
#define FICHEIRO_MONITOR_CONFIG "Monitor.conf"
#define FICHEIRO_SIMULADOR_CONFIG "Simulador.conf"
/***************************************************************************************************************************/

/**ESTRUTURA DO CLIENTE**************************************************************************************************/
typedef struct utilizador
{
	int id;		//Para distinguir uma pessoa de todas as outras	
	int *prioritarios;	//não prioritarios (0) e prioritário(1).
	int estado;	//Fila de bilhete (0), fila do carro(1), a andar no carro (2) ou desistiu (3).
	int tempoEspGuiche;
	int tempoEspCarros;
	int emViagem;
	//int tempoEspDevol;
} utilizador;
/****************************************************************************************************************************/

/**CODIFICAÇÃO DOS EVENTOS***********************************************************************************************/
#define FIM_SIMULACAO -1
#define CRIACAO_CLIENTE 1
// (...)


/**VARIÁVEIS GLOBAIS PARA ESTATÍSTICAS************************************************************************************/
static int nrUtilizadores = 0;
static int nrDesistencias = 0;
static int nrViagens = 0;
static int tempoMedEsp = 0;
static int tempoViagem = 0;
static int tempoEntSaidaCarros = 0;
static int hora,minutos,segundos,minutosAux;
static int tempoSimul = 0;
static int nrUtilizadoresRestantes;
/***************************************************************************************************************************/

/**RENOMEAÇÕES***********************************************************************************************************/
typedef int socket_t;
typedef int client_t;
typedef struct sockaddr_un sockaddr_un;
typedef struct sockaddr sockaddr;
typedef pthread_mutex_t mutex_t;
typedef pthread_t tarefa_t;
typedef sem_t semaforo_t;
/***************************************************************************************************************************/

/**CONFIGURAÇÃO*********************************************************************************************/
typedef struct monitor_config
{
	int t_viagem;
	int max_pessoas;
} monitor_config;

static monitor_config mconf;

// Valores 'default' dos parâmetros de configuração do Monitor
//#define DEFAULT_T_VIAGEM 5
//#define DEFAULT_MAX_PESSOAS 10

typedef struct simulador_config
{
	int prob_chegar_pessoas;
	int t_simulacao;
	int t_viagem;
	int max_pessoas;
} simulador_config;

// Valores 'default' dos parâmetros de configuração do Simulador
// (probabilidades(p) supostamente no formato de 1/p (ex.: 1/10, 1/100, ...)
#define DEFAULT_PROB_CHEGAR_PESSOAS 5
#define DEFAULT_T_SIMULACAO 90
#define DEFAULT_T_VIAGEM 5
#define DEFAULT_MAX_PESSOAS 10

static simulador_config sconf;

void lerConfigMonitor(monitor_config * conf);
void lerConfigSimulador(simulador_config * conf);
int strequals(char * a, char * b);
/***************************************************************************************************************************/

/**SEMÁFORO***************************************************************************************************************/
void inicializarSemaforo(semaforo_t * sem, int v);
void Esperar(semaforo_t * sem);
void Assinalar(semaforo_t * sem);
void destruirSemaforo(semaforo_t * sem);
/***************************************************************************************************************************/

/**TRINCO******************************************************************************************************************/
void inicializarMutex(mutex_t * mutex);
void Fechar(mutex_t * mutex);
void Abrir(mutex_t * mutex);
void destruirMutex(mutex_t * mutex);
/***************************************************************************************************************************/

/**COMUNICAÇÃO***********************************************************************************************************/
void verificarErro(int state);

socket_t criarSocket();
sockaddr_un criarLigacaoSocket();

socket_t criarSocketCliente();

client_t esperarPorCliente();
/***************************************************************************************************************************/

/**MONITOR****************************************************************************************************************/
int lerIntDoSimulador();
void escreverNoLog(char message[]);
void * cliente_act(void *prio);
void criarCliente();
/***************************************************************************************************************************/

/**SIMULADOR**************************************************************************************************************/
void escreverNoMonitor(char message[]);
void escreverIntNoMonitor(int x);
int podeCriarCliente();
/***************************************************************************************************************************/


int randWithProb(double prob);


//Cliente entra para a fila do guiché com prioridades
void entraClienteGuicheCompraPrio(int id);

//Cliente entra para a fila do guiché sem prioridades
void entraClienteGuicheCompraNaoPrio(int id);

//Para controlar as duas filas (prio e não prio) para comprar o bilhete
void * guicheCompraFunc();
