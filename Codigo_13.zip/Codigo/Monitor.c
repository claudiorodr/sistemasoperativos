#include "Header.h"

/***************************************************************************************************************************/
/**VARIÁVEIS GLOBAIS******************************************************************************************************/
/***************************************************************************************************************************/
client_t simulador;
FILE * file;
mutex_t mMonitor;

/***************************************************************************************************************************/
/**MAIN********************************************************************************************************************/
/***************************************************************************************************************************/
int main()
{
	printf("@@@MONITOR@@@\n");

	printf("A configuração está a ser lida..\n");
	lerConfigMonitor(&mconf);
	printf("A configuração foi lida com sucesso.\n");

	printf("À espera do simulador..\n");
	simulador = esperarPorCliente();
	printf("O simulador foi conectado com sucesso.\n");

	printf("---INÍCIO---\n");

	int outputSimulador = 1;

	while(outputSimulador > 0)
	{
		outputSimulador = lerIntDoSimulador();
		//if(outputSimulador == CRIACAO_CLIENTE)
		//{
		//	printf("Foi criado um cliente\n");
		//}

		if(outputSimulador!=-1)
		{
			printf("O cliente %d comprou bilhete\n",outputSimulador);
		}

		//printf("O simulador mandou:%i\n",outputSimulador);			// Mostra o número

		// (...)
		// tratamento de dados (do outputSimulador)
		// (...)
		// conversão numa mensagem (ex.: usado para o log)
		// (...)

		//escreverNoLog("lá vai uma");
	}

	printf("---FIM---\n");

	getchar();

	return 0;
}


/***************************************************************************************************************************/
/**FUNÇÕES AUXILIARES*****************************************************************************************************/
/***************************************************************************************************************************/
int lerIntDoSimulador()
{
	char message[BUFFER_SIZE];
	read(simulador,message,BUFFER_SIZE);
	return atoi(message);
}
