#include "Header.h"
/***************************************************************************************************************************/
/**VARIÁVEIS GLOBAIS******************************************************************************************************/
/***************************************************************************************************************************/
socket_t s;
mutex_t mSimulador;
pthread_t guicheCompra;
/**MODELO - FILA DO GUICHÉ***/
mutex_t mGCP,mGCNP;
semaforo_t semGCP,semGCNP;
int nrPessoasEspGCP=0;
int nrPessoasEspGCNP=0;
/******************************/
/***************************************************************************************************************************/
/**MAIN********************************************************************************************************************/
/***************************************************************************************************************************/
int main()
{
	printf("@@@SIMULADOR@@@\n");
	printf("A configuração está a ser lida..\n");
	lerConfigSimulador(&sconf);
	nrUtilizadoresRestantes = sconf.max_pessoas;
	printf("A configuração foi lida com sucesso.\n");
	s = criarSocketCliente();
	printf("Conectou-se com sucesso ao Monitor.\n");
	srand(time(NULL));

	printf("---INÍCIO---\n");

	inicializarMutex(&mSimulador);
	inicializarMutex(&mGCP);
	inicializarMutex(&mGCNP);
	inicializarSemaforo(&semGCNP,0);
	inicializarSemaforo(&semGCP,0);

	int contador = 0;//Variável para ir incrementado até atingir o valor do delay, só aí é que a informação é enviada para evitar repetir.

	time_t start, end;
	time(&start); //Começou a simulação

	while(nrUtilizadoresRestantes > 0)
	{
		// (...)
		// geração de números (consoante a configuração - probabilidades e etc)
		// (...)		
		if(contador == DELAY_ENTRE_ENVIOS)				//Delay usado para não mostrar o mesmo cliente várias vezes
		{
			contador = 0;	
			if(podeCriarCliente())				//Verificamos se é para criar um cliente
			{
				criarCliente();
			}

			if(randWithProb(sconf.taxa_atendimento))	//Para não vender bilhetes a todos 
			{
				pthread_create(&guicheCompra,NULL,guicheCompraFunc,NULL);
			}			
		}
		contador++;

		time(&end);
		tempoSimul=difftime(end, start);
	}
	pthread_join(guicheCompra,NULL);

	hora = tempoSimul / 3600;      	//Para calcular o nr de horas
	minutosAux = tempoSimul / 60;	//Cálculo intermédio para os minutos
	minutos = minutosAux % 60;		//Para calcular os minutos
	segundos = tempoSimul % 60;		//Para calcular o número de segundos
	printf("Acabou o tempo de simulação: %d hora(s) %d minuto(s) %d segundo(s)\n",hora,minutos,segundos);
	printf("---FIM---\n");

	escreverIntNoMonitor(-1); //Avisa o Monitor que terminou a simulação
	getchar();
	return 0;
}
/***************************************************************************************************************************/
/**FILA DO GUICHÉ**********************************************************************************************************/
/***************************************************************************************************************************/
void entraClienteGuicheCompraPrio(int id)
{
	Fechar(&mGCP);
	nrPessoasEspGCP++;
	printf("Número de clientes prioritários à espera no guiché: %d\n",nrPessoasEspGCP);
	Abrir(&mGCP);
	Esperar(&semGCP);
	Fechar(&mGCP);
	nrPessoasEspGCP--;
	Abrir(&mGCP);
	Fechar(&mSimulador);
	nrUtilizadoresRestantes--;
	Abrir(&mSimulador);
	printf("Número de clientes prioritários à espera no guiché: %d\n",nrPessoasEspGCP);
	//printf("O cliente %d comprou o bilhete\n",id);
	escreverIntNoMonitor(id);
}
void entraClienteGuicheCompraNaoPrio(int id)
{
	Fechar(&mGCNP);
	nrPessoasEspGCNP++;
	printf("Número de clientes não prioritários à espera no guiché: %d\n",nrPessoasEspGCNP);
	Abrir(&mGCNP);
	Esperar(&semGCNP);
	Fechar(&mGCNP);
	nrPessoasEspGCNP--;
	Abrir(&mGCNP);
	Fechar(&mSimulador);
	nrUtilizadoresRestantes--;
	Abrir(&mSimulador);
	printf("Número de clientes não prioritários à espera no guiché: %d\n",nrPessoasEspGCNP);
	//printf("O cliente %d comprou o bilhete\n",id);
	escreverIntNoMonitor(id);
}
void * guicheCompraFunc()
{
	Fechar(&mGCP);
	if(nrPessoasEspGCP>0)
	{
		Abrir(&mGCP);
		Assinalar(&semGCP);
		printf("Foi assinalado o GCP\n");
		//servico();
	}
	else 
	{
		Abrir(&mGCP);
		Fechar(&mGCNP);
		if(nrPessoasEspGCNP>0)
		{
			Abrir(&mGCNP);
			Assinalar(&semGCNP);
			printf("Foi assinalado o GCNP\n");
			//servico();
		}
	}
	Abrir(&mGCP);
	Abrir(&mGCNP);
}
/***************************************************************************************************************************/
/**FUNÇÕES AUXILIARES*****************************************************************************************************/
/***************************************************************************************************************************/
void escreverNoMonitor(char message[])
{
	write(s,message,BUFFER_SIZE);
}
void escreverIntNoMonitor(int x)
{
	char message[BUFFER_SIZE];
	sprintf(message,"%i",x);
	escreverNoMonitor(message);
}
//Função gerar se é para criar um cliente ou não
int podeCriarCliente()
{
	int permissao = randWithProb(sconf.prob_chegar_pessoas);
	if(permissao == CLIENTE_E_CRIADO && nrUtilizadores < sconf.max_pessoas)
	{
		return CLIENTE_E_CRIADO;
	}
	else
	{
		return CLIENTE_NAO_E_CRIADO;
	}
}
//Função para criar a tarefa do clientes
void criarCliente()
{
	Fechar(&mSimulador);
	nrUtilizadores++;
	Abrir(&mSimulador);

	pthread_t cliente;
	pthread_create(&cliente,NULL,cliente_act,(void *)(intptr_t)(randWithProb(0.5)));
}
//Função que vai controlar as ações dos clientes
void * cliente_act(void *prio)
{
	Fechar(&mSimulador);
	utilizador c;
	c.id=nrUtilizadores;
	c.prioritarios=(int *)prio;
	c.estado=0;
	c.tempoEspGuiche=0;
	c.tempoEspCarros=0;
	c.emViagem=0;
	Abrir(&mSimulador);

	char * message = (char *) malloc(sizeof(char *) * BUFFER_SIZE);
	bzero(message,sizeof(message));
	sprintf(message,"Chegou o cliente com o id %d e prioridade %d",c.id,(int)(intptr_t)c.prioritarios);
	printf("%s\n",message);
	escreverNoLog(message);
	free(message);

	Fechar(&mSimulador);
	if(c.prioritarios)
	{
		Abrir(&mSimulador);
		entraClienteGuicheCompraPrio(c.id);
	}
	else
	{
		Abrir(&mSimulador);
		entraClienteGuicheCompraNaoPrio(c.id);
	}
	Abrir(&mSimulador);

	// (...)
}
