#include "Estruturas.h"

void alocaUtilizador(utilizador * u) 
{ u = (utilizador *) malloc(sizeof(utilizador)); }

utilizador * inserirUtilizador(utilizador * u_head, utilizador * u_a_inserir)
{
    utilizador * aux = u_head;
    if(!u_head)
    {
        //printf("%i\n",u_head->id);
        u_head = u_a_inserir;  
        return u_head;
        //printf("%i\n",u_head->id);
    }   
    else
    {
        if(!aux->seguinte)
        {
            aux->seguinte=u_a_inserir;
           return u_head;
        }
        else
        {
            while(aux->seguinte) { aux=aux->seguinte; }
            aux->seguinte=u_a_inserir;
            return u_head;
        }
    }
return u_head;
}
