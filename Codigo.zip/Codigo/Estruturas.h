#include <time.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include "Restricoes.h"

typedef struct utilizador
{
    unsigned int id;
    time_t tempo_entrada;
    time_t tempo_saida;
    unsigned int razao_saida;
    struct utilizador * seguinte;
} utilizador;

void alocaUtilizador(utilizador * u);
utilizador * inserirUtilizador(utilizador * u_head, utilizador * u_a_inserir);
