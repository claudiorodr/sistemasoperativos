#ifndef ESTRUTURAS_H
#define ESTRUTURAS_H

#include <time.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include "Global.h"

/******************************/
/*  DEFINIÇÃO DAS ESTRUTURAS  */
/******************************/
typedef struct utilizador
{
    unsigned int id;
    time_t tempo_entrada;
    time_t tempo_saida;
    unsigned int razao_saida;
} utilizador;

typedef struct fila_u
{
    utilizador * atual;
    struct fila_u * seguinte;
} fila_u;
/******************************/


/********************/
/*  FUNÇÕES GERAIS  */
/********************/

// Utilizador
utilizador * criarUtilizador();
void inicializarUtilizador(utilizador * u);
void inserirUtilizador(fila_u * f, utilizador * u);
fila_u * retirarUtilizador(fila_u * f, utilizador * u);
fila_u * trocarFila(fila_u * f_orig,fila_u * f_dest,utilizador * u);

// Filas
void mostrarTodosOsIds(fila_u * f);
fila_u * criarFila(utilizador * u);
/********************/

/************************/
/*  FUNÇÕES AUXILIARES  */
/************************/
// Utilizador
utilizador * alocaUtilizador();
void apagarUtilizador(utilizador * u);
int forOMesmoUtilizador(utilizador * u1,utilizador * u2);

// Filas
fila_u * alocaFila();
void colocarElementoNaFila(utilizador * u, fila_u * f);
int filaEstaVazia(fila_u * f);
int estiverNoFimDaFila(fila_u * f);
/************************/

#endif
