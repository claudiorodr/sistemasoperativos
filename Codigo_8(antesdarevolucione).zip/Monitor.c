#include "Monitor.h"

void * criarThreadUtilizador()
{
    pthread_t t;
    pthread_create(&t,NULL,(void *)criarUtilizador,NULL);  
}

/************/
/*  MAIN    */
/************/
void main()
{   
    printf("** Estado atual => Simulacao a decorrer! **\n");
 
    fila_u * f_recbil = alocaFila();
    fila_u * f_monrussa = alocaFila();

    utilizador * u1 = criarUtilizador();
    utilizador * u2 = criarUtilizador();
    utilizador * u3 = criarUtilizador();
    utilizador * u4 = criarUtilizador();
    utilizador * u5 = criarUtilizador();    

    inserirUtilizador(f_recbil,u1);
    inserirUtilizador(f_recbil,u2);
    inserirUtilizador(f_recbil,u3);
    inserirUtilizador(f_recbil,u4);
    inserirUtilizador(f_recbil,u5);

    utilizador * u6 = criarUtilizador();
    utilizador * u7 = criarUtilizador();
    utilizador * u8 = criarUtilizador();
    utilizador * u9 = criarUtilizador();
    utilizador * u10 = criarUtilizador();    

    inserirUtilizador(f_monrussa,u6);
    inserirUtilizador(f_monrussa,u7);
    inserirUtilizador(f_monrussa,u8);
    inserirUtilizador(f_monrussa,u9);
    inserirUtilizador(f_monrussa,u10);

    trocarFila(f_recbil,f_monrussa,u4);

    mostrarTodosOsIds(f_monrussa);

}
