#include "Estruturas.h"

/********************/
/*  FUNÇÕES GERAIS  */
/********************/

// Utilizador
utilizador * criarUtilizador()
{
    utilizador * u = alocaUtilizador();
    inicializarUtilizador(u);
    printf("Chegou o utilizador nº %i\n",u->id);
    return u;
}

void inicializarUtilizador(utilizador * u)
{
    nr_utilizadores++;
    u->id = nr_utilizadores;
    //u->tempo_entrada = time(NULL);
}

void inserirUtilizador(fila_u * f, utilizador * u)
{ 
    if(filaEstaVazia(f)) { colocarElementoNaFila(u,f); }

    else
    {
        fila_u * aux = f;
        
        while(!estiverNoFimDaFila(aux)) 
            aux = aux->seguinte;
            
        fila_u * aux_u = criarFila(u);

        aux->seguinte = aux_u;
    }
}

fila_u * retirarUtilizador(fila_u * f, utilizador * u)
{
    if(!filaEstaVazia(f))
    {
        fila_u * aux = f;
    
        if(forOMesmoUtilizador(aux->atual,u))
        {
            f = aux->seguinte;
            free(aux);
            return f;
        }

        else
        {
            fila_u * aux_seguinte = aux->seguinte;
            
            while(!estiverNoFimDaFila(aux_seguinte))
            {
                if(forOMesmoUtilizador(aux_seguinte->atual,u))
                {
                   aux->seguinte = aux_seguinte->seguinte;
                   return f;
                }
                else
                {
                    aux = aux_seguinte;
                    aux_seguinte = aux_seguinte->seguinte;
                }
            }

            aux->seguinte = NULL;
            return f;
        }
    }
}

fila_u * trocarFila(fila_u * f_orig,fila_u * f_dest,utilizador * u)
{
    f_orig = retirarUtilizador(f_orig,u);
    inserirUtilizador(f_dest,u);    
}

// Filas
void mostrarTodosOsIds(fila_u * f)
{
    fila_u * aux = f;

    printf("%i\n",aux->atual->id);

    while(!estiverNoFimDaFila(aux))
    {
        printf("%i\n",aux->seguinte->atual->id);
        aux = aux->seguinte;
    }
}

fila_u * criarFila(utilizador * u)
{
    fila_u * f = alocaFila();
    f->atual = u;
    f->seguinte = NULL;
    return f;
}




/********************/

/************************/
/*  FUNÇÕES AUXILIARES  */
/************************/
// Utilizador
utilizador * alocaUtilizador() { return (utilizador *) malloc(sizeof(utilizador)); }
void apagarUtilizador(utilizador * u) { free(u); }
int forOMesmoUtilizador(utilizador * u1,utilizador * u2) { return u1->id == u2->id; }

// Filas
fila_u * alocaFila() { return (fila_u *) malloc(sizeof(fila_u)); }
void colocarElementoNaFila(utilizador * u, fila_u * f) { f->atual = u; }
int filaEstaVazia(fila_u * f) { return !f->atual; }
int estiverNoFimDaFila(fila_u * f) { return !f->seguinte; }
/************************/
