#ifndef ESTRUTURAS_H
#define ESTRUTURAS_H

#include <time.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include "Global.h"

typedef struct utilizador
{
    unsigned int id;
    time_t tempo_entrada;
    time_t tempo_saida;
    unsigned int razao_saida;
} utilizador;

typedef struct fila_u
{
    utilizador * atual;
    struct fila_u * seguinte;
} fila_u;

void mostrarTodosOsIds(fila_u * f);

void inserirUtilizador(fila_u * f, utilizador * u);
void removerUtilizador(fila_u * f, utilizador * u);

utilizador * criarUtilizador();
fila_u * criarFila(utilizador * u);

void inicializarUtilizador(utilizador * u);

utilizador * alocaUtilizador();
fila_u * alocaFila();

void colocarElementoNaFila(utilizador * u, fila_u * f);
int filaEstaVazia(fila_u * f);
int estiverNoFimDaFila(fila_u * f);
int forOMesmoUtilizador(utilizador * u1,utilizador * u2);

#endif
