#include "Estruturas.h"

void mostrarTodosOsIds(fila_u * f)
{
    fila_u * aux = f;

    printf("%i\n",aux->atual->id);

    while(aux->seguinte!=NULL)
    {
        printf("%i\n",aux->seguinte->atual->id);
        aux = aux->seguinte;
    }
}

void inserirUtilizador(fila_u * f, utilizador * u)
{ 
    if(filaEstaVazia(f)) { colocarElementoNaFila(u,f); }

    else
    {
        fila_u * aux = f;
        
        while(!estiverNoFimDaFila(aux)) 
            aux = aux->seguinte;
            
        fila_u * aux_u = criarFila(u);

        aux->seguinte = aux_u;
    }
}

void removerUtilizador(fila_u * f, utilizador * u)
{
    if(!filaEstaVazia(f))
    {
        fila_u * aux = f;
    
        if(forOMesmoUtilizador(aux->atual,u))
        {
            printf("Antes: %i\n",f->atual->id);
            f = f->seguinte;
            printf("Depois: %i\n",f->atual->id);
            aux->seguinte = NULL;
            free(aux);
            return;   
        }

        else
        {
            fila_u * aux_seguinte = aux->seguinte;

            while(!forOMesmoUtilizador(aux_seguinte->atual,u))
            {  
                aux = aux->seguinte;
                aux_seguinte = aux_seguinte->seguinte;
            }

            if(!estiverNoFimDaFila(aux_seguinte))
            {
                aux->seguinte = NULL;
                free(aux_seguinte);
            }
        }
    }
}
            

utilizador * criarUtilizador()
{
    utilizador * u = alocaUtilizador();
    inicializarUtilizador(u);
    printf("Chegou o utilizador nº %i\n",u->id);
    return u;
}

fila_u * criarFila(utilizador * u)
{
    fila_u * f = alocaFila();
    f->atual = u;
    f->seguinte = NULL;
    return f;
}

void inicializarUtilizador(utilizador * u)
{
    nr_utilizadores++;
    u->id = nr_utilizadores;
    //u->tempo_entrada = time(NULL);
}

utilizador * alocaUtilizador()
{ 
    return (utilizador *) malloc(sizeof(utilizador)); 
}
fila_u * alocaFila()
{
    return (fila_u *) malloc(sizeof(fila_u));
}


int forOMesmoUtilizador(utilizador * u1,utilizador * u2) { return u1->id == u2->id; }
void colocarElementoNaFila(utilizador * u, fila_u * f) { f->atual = u; }
int filaEstaVazia(fila_u * f) { return !f->atual; }
int estiverNoFimDaFila(fila_u * f) { return !f->seguinte; }
