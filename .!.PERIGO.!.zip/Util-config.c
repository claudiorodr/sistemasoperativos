#include "Header.h"
/************************************************************************************************************/
/**LEITURA DO FICHEIRO DE CONFIGURAÇÃO DO MONITOR******************************************************/
/***************************/
void lerConfigMonitor(monitor_config * conf)
{
	FILE * fp = fopen(FICHEIRO_MONITOR_CONFIG,"r+");

	Fechar(&m_mconf);

	conf->t_viagem = DEFAULT_T_VIAGEM;
	conf->max_pessoas = DEFAULT_MAX_PESSOAS_TOTAL;

	char buffer[BUFFER_SIZE];
	char param[BUFFER_SIZE];
	char value[BUFFER_SIZE];

	int i;

	while(fgets(buffer,BUFFER_SIZE,fp))
	{
		for(i = 0 ; buffer[i] != '=' ; i++);
	
		bzero(param,sizeof(param));
		bzero(value,sizeof(value));

		strncpy(param,buffer,i);	
		strncpy(value,buffer+i+1,strlen(buffer)-i-1);

		if(strequals(param,"t_viagem"))
		{
			conf->t_viagem = atoi(value); 
		}
		else
		{
		if(strequals(param,"max_pessoas"))
		{
			conf->max_pessoas = atoi(value);
		}
		else
		{
			//...
		}
		}

		bzero(param,sizeof(param));
		bzero(value,sizeof(value));
		bzero(buffer,sizeof(buffer));
	}

	Abrir(&m_mconf);
}
/************************************************************************************************************/
/**LEITURA DO FICHEIRO DE CONFIGURAÇÃO DO SIMULADOR***************************************************/
/****************************************************************/
void lerConfigSimulador(simulador_config * conf)
{
	FILE * fp = fopen(FICHEIRO_SIMULADOR_CONFIG,"r+");
	
	Fechar(&m_sconf);

	conf->taxa_populacao = DEFAULT_TAXA_POPULACAO;
	conf->t_simulacao = DEFAULT_T_SIMULACAO;
	conf->t_viagem = DEFAULT_T_VIAGEM;
	conf->max_pessoas_total = DEFAULT_MAX_PESSOAS_TOTAL;
	conf->taxa_atendimento_compra = DEFAULT_TAXA_ATENDIMENTO_COMPRA;
	conf->taxa_atendimento_dev = DEFAULT_TAXA_ATENDIMENTO_DEV;
	conf->taxa_atendimento_carros = DEFAULT_TAXA_ATENDIMENTO_CARROS;
	conf->max_pessoas_dev = DEFAULT_MAX_PESSOAS_DEV;
	conf->taxa_desistencia = DEFAULT_PROB_DESISTENCIA;
	conf->lotacao_carro = DEFAULT_LOTACAO_CARRO;

	char buffer[BUFFER_SIZE];
	char param[BUFFER_SIZE];
	char value[BUFFER_SIZE];

	int i;

	while(fgets(buffer,BUFFER_SIZE,fp))
	{
		for(i = 0 ; buffer[i] != '=' ; i++);
	
		bzero(param,sizeof(param));
		bzero(value,sizeof(value));

		strncpy(param,buffer,i);	
		strncpy(value,buffer+i+1,strlen(buffer)-i-1);

		if(strequals(param,"taxa_populacao"))
		{
			conf->taxa_populacao = atof(value); 
		}
		else
		{
		if(strequals(param,"t_simulacao"))
		{
			conf->t_simulacao = atoi(value);		
			// (...)
		}
		else
		{
		if(strequals(param,"t_viagem"))
		{
			conf->t_viagem = atoi(value); 
		}
		else
		{
		if(strequals(param,"max_pessoas_total"))
		{
			conf->max_pessoas_total = atoi(value);
		}
		else
		{
		if(strequals(param,"taxa_atendimento_compra"))
		{
			conf->taxa_atendimento_compra = atof(value);
		}
		else
		{
		if(strequals(param,"taxa_atendimento_dev"))
		{
			conf->taxa_atendimento_dev = atof(value);
		}
		else
		{
		if(strequals(param,"max_pessoas_dev"))
		{
			conf->max_pessoas_dev = atof(value);
		}
		else
		{
		if(strequals(param,"taxa_desistencia"))
		{
			conf->taxa_desistencia = atof(value);
		}
		else
		{
		if(strequals(param,"lotacao_carro"))
		{
			conf->lotacao_carro = atoi(value);
		}
		else
		{
		if(strequals(param,"taxa_atendimento_carros"))
		{
			conf->taxa_atendimento_carros = atof(value);
		}
		}
		}
		}
		}
		}
		}
		}
		}
		}

		bzero(param,sizeof(param));
		bzero(value,sizeof(value));
		bzero(buffer,sizeof(buffer));
	}

	Abrir(&m_sconf);
}
