#include "Header.h"
/***************************************************************************************************************************/
/**VARIÁVEIS GLOBAIS******************************************************************************************************/
/***************************************************************************************************************************/
socket_t s;
mutex_t m_comunicacao;
/**MODELO - GUICHÉ DE COMPRA************/
tarefa_t guicheCompra;
mutex_t mGCP;
semaforo_t sGCP;
int nrPessoasEspGCP=0;
mutex_t mGCNP;
semaforo_t sGCNP;
int nrPessoasEspGCNP=0;
/*******************************************/
/**MODELO - GUICHÉ DE DEVOLUÇÃO*********/
tarefa_t guicheDevolucao;
mutex_t mDev;
semaforo_t sClienteDev,sDev;
int nrPessoasEspDev = 0;
/*******************************************/
/**MODELO - CARROS DA MONTANHA-RUSSA********/
tarefa_t filaCarros;
mutex_t mCarros;
semaforo_t sFilaCarros,sCarro1,sCarro2;
int nrPessoasEspCarros = 0;
int tipo_carro = 1;
int viagemEmCurso = 0;
int nrPessoasSentadas = 0;
int nrPessoasEspCarro1 = 0;
int nrPessoasEspCarro2 = 0;
time_t start,end,inicioViagem,tempoAtualViagem;
/***************************************************************************************************************************/
/**MAIN******************************************************************************************************/
/***************************************************************************************************************************/
int main()
{
	printf("@@@SIMULADOR@@@\n");
	printf("A configuração está a ser lida..\n");
	lerConfigSimulador(&sconf);
	Fechar(&m_nrUtilizadoresRestantes);
	nrUtilizadoresRestantes = sconf.max_pessoas_total;
	Abrir(&m_nrUtilizadoresRestantes);

	printf("A configuração foi lida com sucesso.\n");
	s = criarSocketCliente();
	printf("Conectou-se com sucesso ao Monitor.\n");
	srand(time(NULL));

	char log[BUFFER_SIZE];	

	sprintf(log,"---INÍCIO---\n");
	printf("%s",log);
	escreverNoLog(log);
	printf("********************************************************************************\n");
	
	inicializarMutex(&m_comunicacao);
	inicializarMutex(&mGCP);		//Mutex para a fila do guiché com prioridade
	inicializarMutex(&mGCNP);		//Mutex para a fila do guiché sem prioridade
	inicializarMutex(&mDev);
	inicializarMutex(&mCarros);
	inicializarSemaforo(&sGCNP,0);		//Semáforo para a fila do guiché sem prioridade
	inicializarSemaforo(&sGCP,0);		//SEmáforo para a fila do guiché com prioridade
	inicializarSemaforo(&sClienteDev,0);	//Semaforo para os clientes que chegam à fila de devoluções 
	inicializarSemaforo(&sDev,0);		//Semaforo para o homem que efetua as devoluções
	inicializarSemaforo(&sFilaCarros,0);
	inicializarSemaforo(&sCarro1,sconf.lotacao_carro);
	inicializarSemaforo(&sCarro2,sconf.lotacao_carro);

	time_t start, end;
	time(&start); //Começou a simulação

	pthread_create(&guicheCompra,NULL,guicheCompraFunc,NULL);
	pthread_create(&guicheDevolucao,NULL,filaDev,NULL);
	pthread_create(&filaCarros,NULL,filaEsperaCarros,NULL);

	Fechar(&m_nrUtilizadoresRestantes);
	while(nrUtilizadoresRestantes > 0)
	{
		Abrir(&m_nrUtilizadoresRestantes);
		delay();
		if(podeCriarCliente())				//Verificamos se é para criar um cliente
		{
			criarCliente();
		}
		
		Fechar(&mCarros);
		if(!viagemEmCurso && nrUtilizadoresRestantes < 4)
		{
			printf("Estes %i tiveram que ser expulsos, devido à falta de pessoas para a diversão\n",nrUtilizadoresRestantes);
			Abrir(&mCarros);
			break;
		}
		else Abrir(&mCarros);

		time(&end);
		tempoSimul=difftime(end, start);
	}
	Abrir(&m_nrUtilizadoresRestantes);

	hora = tempoSimul / 3600;      	//Para calcular o nr de horas
	minutosAux = tempoSimul / 60;	//Cálculo intermédio para os minutos
	minutos = minutosAux % 60;		//Para calcular os minutos
	segundos = tempoSimul % 60;		//Para calcular o número de segundos

	printf("********************************************************************************\n");
	sprintf(log,"Acabou o tempo de simulação: %d hora(s) %d minuto(s) %d segundo(s)\n",hora,minutos,segundos);
	printf("%s",log);
	escreverNoLog(log);
	printf("********************************************************************************\n");
	
	Fechar(&m_comunicacao);
	escreverIntNoMonitor(FIM_SIMULACAO); //Avisa o Monitor que terminou a simulação
	escreverIntNoMonitor(nrUtilizadores);
	Abrir(&m_comunicacao);

	sprintf(log,"---FIM---\n");
	printf("%s",log);
	escreverNoLog(log);

	getchar();
	return 0;
}
/***************************************************************************************************************************/
/**GUICHÉ DE COMPRA******************************************************************************************************/
/***************************************************************************************************************************/
void entraClienteGuicheCompraPrio(int id)
{
	Fechar(&mGCP);
	nrPessoasEspGCP++;
	printf("Número de clientes prioritários à espera no guiché: %d\n",nrPessoasEspGCP);
	Abrir(&mGCP);
	Esperar(&sGCP);
}
void entraClienteGuicheCompraNaoPrio(int id)
{
	Fechar(&mGCNP);
	nrPessoasEspGCNP++;
	printf("Número de clientes não prioritários à espera no guiché: %d\n",nrPessoasEspGCNP);
	Abrir(&mGCNP);
	Esperar(&sGCNP);
}
void * guicheCompraFunc()
{
	int i;
	while(1)
	{
		delay();
		if(randWithProb(sconf.taxa_atendimento_compra))	//Para não vender bilhetes a todos 
		{
			Fechar(&mGCP);
			if(nrPessoasEspGCP>0)
			{
				nrPessoasEspGCP--;
				Abrir(&mGCP);
				Assinalar(&sGCP);
				printf("Foi assinalado o GCP\n");
			}
			else 
			{
				Abrir(&mGCP);
				Fechar(&mGCNP);
				if(nrPessoasEspGCNP>0)
				{
					nrPessoasEspGCNP--;
					Abrir(&mGCNP);
					Assinalar(&sGCNP);
					printf("Foi assinalado o GCNP\n");
				}
				else Abrir(&mGCNP);
			}
		}
	}
}
/***************************************************************************************************************************/
/**GUICHÉ DE DEVOLUÇÃO**************************************************************************************************/
/***************************************************************************************************************************/
int entraClienteDev()
{
	Fechar(&mDev);
	if(nrPessoasEspDev < sconf.max_pessoas_dev)
	{
		nrPessoasEspDev++;
		Abrir(&mDev);
		Assinalar(&sClienteDev);	//Assinalar que já existe clientes a espera.Inicializado a 0.
		Esperar(&sDev);
		return CLIENTE_DESISTE;
	}
	else
	{
		Abrir(&mDev);
		return CLIENTE_NAO_DESISTE;
	}
}
void * filaDev()
{
	int i;
	while(1)
	{
		delay();
		if(randWithProb(sconf.taxa_atendimento_dev))	//Para não vender bilhetes a todos 
		{
			Esperar(&sClienteDev);

			Fechar(&mDev);
			nrPessoasEspDev--;
			Abrir(&mDev);

			Assinalar(&sDev);
		}
	}
}
/***************************************************************************************************************************/
/**FILA DOS CARROS**********************************************************************************************************/
/***************************************************************************************************************************/
void entraClienteCarros(int id)
{
	Fechar(&m_nrUtilizadores);
	if(nrUtilizadoresRestantes>=4)
	{
		Abrir(&m_nrUtilizadores);
		
		Fechar(&mCarros);
		if(tipo_carro == 1)
		{	
			tipo_carro = 2;	
			nrPessoasEspCarro1++;
			Abrir(&mCarros);
		
			printf("O cliente %d entrou na fila de espera para o carro 1\n",id);
			Esperar(&sCarro1);
			printf("O cliente %d vai entrar no carro 1\n",id);
			
			Fechar(&mCarros);
			nrPessoasEspCarro1--;
			Abrir(&mCarros);
		}
		else if(tipo_carro == 2)
		{
			tipo_carro = 1;	
			nrPessoasEspCarro2++;
			Abrir(&mCarros);
			
			printf("O cliente %d entrou na fila de espera para o carro 2\n",id);
			Esperar(&sCarro2);
			printf("O cliente %d vai entrar no carro 2\n",id);
			
			Fechar(&mCarros);
			nrPessoasEspCarro2--;
			Abrir(&mCarros);
		}
		
		Fechar(&mCarros);
		nrPessoasSentadas++;
		Abrir(&mCarros);
		
		Esperar(&sFilaCarros);
		
		time(&inicioViagem);
		printf("Começou a viagem para o cliente %d\n",id);
		
		Fechar(&mCarros);
		nrPessoasSentadas--;
		Abrir(&mCarros);
		
		Fechar(&mCarros);
		viagemEmCurso=1;
		Abrir(&mCarros);
  }
	else
	{
		Abrir(&m_nrUtilizadores);
		
		entraClienteDev();
		printf("Desistencia forcada (por falta de pessoas para a diversão)\n");
	}
}
void * filaEsperaCarros()
{
	char log[BUFFER_SIZE];
	while(1)
	{
		delay();
		if(randWithProb(sconf.taxa_atendimento_carros))
		{
			if(viagemEmCurso)
			{
				time(&tempoAtualViagem);
				tempoViagem=difftime(tempoAtualViagem,inicioViagem);
			}
		
			if(tempoViagem >= sconf.t_viagem)
			{
				sprintf(log,"**Fim da viagem (a viagem durou %d segundos)**\n",tempoViagem);
				printf("%s",log);
				escreverNoLog(log);
				tempoViagem=0;	
				viagemEmCurso=0;
				fimDaViagem();
			}
			
			Fechar(&mCarros);
	
			if(nrPessoasSentadas == sconf.lotacao_carro)	//O 4 é o número de pessoas no total 
			{
				printf("**Início da viagem**\n");
				int j;
				for(j=0;j < sconf.lotacao_carro;j++)
				{
					Assinalar(&sFilaCarros);
				}
			}
		
			Abrir(&mCarros);
		}
	}
}
void fimDaViagem()
{
	int i;
	Fechar(&m_nrUtilizadores);
	nrUtilizadoresRestantes -= sconf.lotacao_carro;
	Abrir(&m_nrUtilizadores);
	
	for(i=1;i <= sconf.lotacao_carro;i++)
	{
		Fechar(&m_nrUtilizadores);
		if((i%2)==0 && nrUtilizadoresRestantes >= sconf.lotacao_carro)
		{
			Abrir(&m_nrUtilizadores);
			Assinalar(&sCarro1);
			printf("Assinalou carro 1\n");
		}
		else if((i%2)!=0 && nrUtilizadoresRestantes >= sconf.lotacao_carro)
		{
			Abrir(&m_nrUtilizadores);
			Assinalar(&sCarro2);
			printf("Assinalou carro 2\n");
		}
		else {	Abrir(&m_nrUtilizadores); }
	}
}
/***************************************************************************************************************************/
/**CLIENTE*****************************************************************************************************************/
/***************************************************************************************************************************/
//Função gerar se é para criar um cliente ou não
int podeCriarCliente()
{
	int permissao = randWithProb(sconf.taxa_populacao);
	if(permissao && nrUtilizadores < sconf.max_pessoas_total)
	{
		return CLIENTE_E_CRIADO;
	}
	else
	{
		return CLIENTE_NAO_E_CRIADO;
	}
}
//Função para criar a tarefa do clientes
void criarCliente()
{
		Fechar(&m_nrUtilizadores);
		nrUtilizadores++;
		Abrir(&m_nrUtilizadores);

		pthread_t cliente;
		pthread_create(&cliente,NULL,cliente_act,(void *)(intptr_t)(randWithProb(0.5)));
}
//Função que vai controlar as ações dos clientes
void * cliente_act(void *prio)
{
	time_t tempoChegadaG,TempoSaidaG,tempoInicioDev,tempoSaidaDev; //tempo de chegada e saída da fila do guiché
	utilizador c;
	Fechar(&m_nrUtilizadores);
	c.id=nrUtilizadores;
	Abrir(&m_nrUtilizadores);
	c.prioritarios=(int *)prio;
	c.tempoEspGuiche=0;
	c.tempoEspCarros=0;
	c.tempoEspDev=0;
	c.emViagem=0;
	c.estado=0;
	c.emViagem=0;

	char log[BUFFER_SIZE];
	sprintf(log,"Chegou o cliente com o id %d e prioridade %d\n",c.id,(int)(intptr_t)c.prioritarios);//Faz cópia da string para log
	printf("%s",log);
	escreverNoLog(log);
	Fechar(&m_comunicacao);
	escreverIntNoMonitor(CHEGAR_GUICHE_COMPRA);
	escreverIntNoMonitor(c.id);
	escreverIntNoMonitor((int)(intptr_t)(c.prioritarios));
	Abrir(&m_comunicacao);

	if(c.prioritarios)
	{
		time(&tempoChegadaG);
		entraClienteGuicheCompraPrio(c.id);
		time(&TempoSaidaG);
		c.tempoEspGuiche=difftime(TempoSaidaG, tempoChegadaG);

		Fechar(&m_comunicacao);
		escreverIntNoMonitor(COMPRA_BILHETE);
		escreverIntNoMonitor(c.id);
		escreverIntNoMonitor(c.tempoEspGuiche);
		Abrir(&m_comunicacao);

		time(&tempoInicioDev);
		
		if(veSeDesiste())
		{
			time(&tempoSaidaDev);
			c.tempoEspDev=difftime(tempoSaidaDev,tempoInicioDev);
			
			Fechar(&m_nrDesistencias);
			nrDesistencias++;
			Abrir(&m_nrDesistencias);
			
			fflush(stdout);
			printf("O cliente %d vai desistir\n",c.id);
			fflush(stdout);
			
			Fechar(&m_comunicacao);
			escreverIntNoMonitor(DESISTENCIA);
			escreverIntNoMonitor(c.id);
			escreverIntNoMonitor(nrDesistencias);
			escreverIntNoMonitor(c.tempoEspDev);
			Abrir(&m_comunicacao);
			
			Fechar(&m_nrUtilizadoresRestantes);
			nrUtilizadoresRestantes--;
			Abrir(&m_nrUtilizadoresRestantes);
		}
		else
		{
			entraClienteCarros(c.id);
		}
	}
	else
	{
		time(&tempoChegadaG);
		entraClienteGuicheCompraNaoPrio(c.id);
		time(&TempoSaidaG);
		c.tempoEspGuiche=difftime(TempoSaidaG, tempoChegadaG);

		Fechar(&m_comunicacao);
		escreverIntNoMonitor(COMPRA_BILHETE);
		escreverIntNoMonitor(c.id);
		escreverIntNoMonitor(c.tempoEspGuiche);
		Abrir(&m_comunicacao);

		time(&tempoInicioDev);

		if(veSeDesiste())
		{	
			time(&tempoSaidaDev);
			c.tempoEspDev=difftime(tempoSaidaDev,tempoInicioDev);
			
			Fechar(&m_nrDesistencias);
			nrDesistencias++;
			Abrir(&m_nrDesistencias);
			
			fflush(stdout);
			printf("O cliente %d vai desistir\n",c.id);
			fflush(stdout);
			
			Fechar(&m_comunicacao);
			escreverIntNoMonitor(DESISTENCIA);
			escreverIntNoMonitor(c.id);
			escreverIntNoMonitor(nrDesistencias);
			escreverIntNoMonitor(c.tempoEspDev);
			Abrir(&m_comunicacao);
			
			Fechar(&m_nrUtilizadoresRestantes);
			nrUtilizadoresRestantes--;
			Abrir(&m_nrUtilizadoresRestantes);
		}
		else
		{
			entraClienteCarros(c.id);
		}
	}
}
int veSeDesiste()
{
	if(randWithProb(sconf.taxa_desistencia))
	{
		return entraClienteDev();
	}
	else
	{
		return CLIENTE_NAO_DESISTE;
	}
}
/***************************************************************************************************************************/
/**FUNÇÕES AUXILIARES*****************************************************************************************************/
/***************************************************************************************************************************/
void escreverNoMonitor(char message[])
{
	write(s,message,BUFFER_SIZE);
}
void escreverIntNoMonitor(int x)
{
	char message[BUFFER_SIZE];
	sprintf(message,"%i",x);
	escreverNoMonitor(message);
}
