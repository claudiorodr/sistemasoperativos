/**BIBLIOTECAS*************************************************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <pthread.h>
#include <unistd.h>
#include <semaphore.h>
#include <math.h>
/***************************************************************************************************************************/
/**CONSTANTES PARA SOCKETS**********************************************************************************************/
#define UNIXSTR_PATH "/tmp/s.unixstr"
#define UNIXDG_PATH  "/tmp/s.unixdgx"
#define UNIXDG_TMP   "/tmp/dgXXXXXXX"
/***************************************************************************************************************************/
/**CONSTANTES GERAIS*****************************************************************************************************/
#define FOREVER 1
#define BUFFER_SIZE 255
#define DELAY_ENTRE_ENVIOS 9000000
#define ERROR -1
#define APPEND_MODE "a"
#define FICHEIRO_LOG "log.log"
#define FICHEIRO_MONITOR_CONFIG "Monitor.conf"
#define FICHEIRO_SIMULADOR_CONFIG "Simulador.conf"
/***************************************************************************************************************************/
/**ESTRUTURA DO CLIENTE**************************************************************************************************/
typedef struct utilizador
{
	int id;		//Para distinguir uma pessoa de todas as outras	
	int *prioritarios;	//não prioritarios (0) e prioritário(1).
	int estado;	//Fila de bilhete (0), fila do carro(1), a andar no carro (2) ou desistiu (3).
	int tempoEspGuiche;
	int tempoEspCarros;
	int tempoEspDev;
	int emViagem;
} utilizador;
/****************************************************************************************************************************/
/**CODIFICAÇÃO DOS EVENTOS***********************************************************************************************/
#define FIM_SIMULACAO 0
#define COMPRA_BILHETE 1
#define DESISTENCIA 2
#define ENVIO_NR_VIAGENS 3
// (...)
/**VARIÁVEIS GLOBAIS PARA ESTATÍSTICAS************************************************************************************/
static int nrUtilizadores = 0;
static int nrDesistencias = 0;
static int nrViagens = 0;
static double tempoMedEspG = 0;
static double tempoMedEspDev = 0;
static int tempoViagem = 0;
static int tempoEntSaidaCarros = 0;
static int hora,minutos,segundos,minutosAux;
static int tempoSimul = 0;
static int nrUtilizadoresRestantes;
/***************************************************************************************************************************/
/**RENOMEAÇÕES***********************************************************************************************************/
typedef int socket_t;
typedef int client_t;
typedef struct sockaddr_un sockaddr_un;
typedef struct sockaddr sockaddr;
typedef pthread_mutex_t mutex_t;
typedef pthread_t tarefa_t;
typedef sem_t semaforo_t;
/***************************************************************************************************************************/
/**CONFIGURAÇÃO (Monitor)*************************************************************************************************/
typedef struct monitor_config
{
	int t_viagem;
	int max_pessoas;
} monitor_config;
static monitor_config mconf;
// Valores 'default' dos parâmetros de configuração do Monitor
//#define DEFAULT_T_VIAGEM 5
//#define DEFAULT_MAX_PESSOAS 10
/***************************************************************************************************************************/
/**CONFIGURAÇÃO (Simulador)***********************************************************************************************/
typedef struct simulador_config
{
	int prob_chegar_pessoas;
	int duracao_viagem;
	int max_pessoas_total;
	int taxa_atendimento_compra;
	int taxa_atendimento_dev;
	int taxa_atendimento_carros;
	int max_pessoas_dev;
	int prob_desistencia;
} simulador_config;
static simulador_config sconf;
// Valores 'default' dos parâmetros de configuração do Simulador
#define DEFAULT_PROB_CHEGAR_PESSOAS 3
#define DEFAULT_T_SIMULACAO 90
#define DEFAULT_DURACAO_VIAGEM 5
#define DEFAULT_MAX_PESSOAS_TOTAL 15
#define DEFAULT_TAXA_ATENDIMENTO_COMPRA 3
#define DEFAULT_TAXA_ATENDIMENTO_DEV 3
#define DEFAULT_TAXA_ATENDIMENTO_CARROS 3
#define DEFAULT_MAX_PESSOAS_DEV 10
#define DEFAULT_PROB_DESISTENCIA 3
/***************************************************************************************************************************/
/**SIMULADOR - MODELOS DE SINCRONIZAÇÃO********************************************************************************/
/**MODELO - GUICHÉ DE COMPRA************/
void entraClienteGuicheCompraPrio(int id);
void entraClienteGuicheCompraNaoPrio(int id);
void * guicheCompraFunc();
/*******************************************/
/**MODELO - GUICHÉ DE DEVOLUÇÃO********/
int veSeDesiste(utilizador * c);
int entraClienteDev(utilizador * c);
void * filaDev();
#define CLIENTE_DESISTE 1
#define CLIENTE_NAO_DESISTE 0
/********************************************/
/**MODELO - CARROS SEM PRIORIDADE*******/

void * FilaDosCarrosSP();
void entraclienteCarrosSP(utilizador * c);
void fimDaViagem();
/*******************************************/
/*******************************************/
/***************************************************************************************************************************/
/**MONITOR****************************************************************************************************************/
int lerIntDoSimulador();
char* lerDoSimulador();
void converteMens(int *terminar,char mensagem[]);
/***************************************************************************************************************************/
/**SIMULADOR**************************************************************************************************************/
void escreverNoMonitor(char message[]);
void escreverIntNoMonitor(int x);
int podeCriarCliente();
void criarCliente();
void * cliente_act(void *prio);
#define CLIENTE_E_CRIADO 1
#define CLIENTE_NAO_E_CRIADO 0
/***************************************************************************************************************************/
/**UTIL-SINCRONIZAÇÃO*****************************************************************************************************/
void inicializarMutex(mutex_t * mutex);
void Fechar(mutex_t * mutex);
void Abrir(mutex_t * mutex);
void destruirMutex(mutex_t * mutex);
void inicializarSemaforo(semaforo_t * sem, int v);
void Esperar(semaforo_t * sem);
void Assinalar(semaforo_t * sem);
void destruirSemaforo(semaforo_t * sem);
/**UTIL-COMUNICAÇÃO******************************************************************************************************/
socket_t criarSocket();
sockaddr_un criarLigacaoSocket();
socket_t criarSocketCliente();
client_t esperarPorCliente();
/***************************************************************************************************************************/
/**UTIL-CONFIGURAÇÃO*****************************************************************************************************/
void lerConfigMonitor(monitor_config * conf);
void lerConfigSimulador(simulador_config * conf);
/***************************************************************************************************************************/
/**UTIL-GERAL*********************************************************************************************************************/
int randWithProb(double prob);
void escreverNoLog(char message[]);
int strequals(char * a, char * b);
void verificarErro(int state);
/***************************************************************************************************************************/
