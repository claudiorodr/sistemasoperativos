#include "Header.h"
/***************************************************************************************************************************/
/**VARIÁVEIS GLOBAIS******************************************************************************************************/
/***************************************************************************************************************************/
socket_t s;
mutex_t mSimulador,mDesistencias,controlaNrUtilizadores;
/**MODELO - GUICHÉ DE COMPRA************/
mutex_t mGCP,mGCNP;
pthread_t guicheCompra;
semaforo_t semGCP,semGCNP;
int nrPessoasEspGCP=0;
int nrPessoasEspGCNP=0;
pthread_t guicheCompra;
pthread_t guicheDevolucao;
/*******************************************/
/**MODELO - GUICHÉ DE DEVOLUÇÃO********/
mutex_t mDev,mDesistencias;
semaforo_t semClienteDev,semDev;
pthread_t guicheDevolucao;
int nrPessoasEspDev = 0;
/*********************** MODELO - CARROS SEM PRIORIDADE******************************/
int tipo =1;
int comecouViagem=0;
int nPessoasnoscarros=0;
int clientesEsperacarro2=0;
int clientesEsperacarro1=0;
mutex_t mCarrosSP;
pthread_t filaCarros;
semaforo_t sCarros,sCarros1,sCarros2;
time_t start, end,inicioViagem,tempoAtualViagem;
/***************************************************************************************************************************/
/**MAIN******************************************************************************************************/
/***************************************************************************************************************************/
int main()
{
	printf("@@@SIMULADOR@@@\n");
	printf("A configuração está a ser lida..\n");
	lerConfigSimulador(&sconf);
	nrUtilizadoresRestantes = sconf.max_pessoas_total;
	printf("A configuração foi lida com sucesso.\n");
	s = criarSocketCliente();
	printf("Conectou-se com sucesso ao Monitor.\n");
	srand(time(NULL));

	printf("---INÍCIO---\n");

	inicializarMutex(&mSimulador);

	inicializarMutex(&mGCP);
	inicializarMutex(&mGCNP);
	inicializarSemaforo(&semGCNP,0);
	inicializarSemaforo(&semGCP,0);

	inicializarSemaforo(&semClienteDev,0);
	inicializarSemaforo(&semDev,0);

	inicializarMutex(&mCarrosSP);
	inicializarSemaforo(&sCarros,0);
	inicializarSemaforo(&sCarros1,2);
	inicializarSemaforo(&sCarros2,2);

	int contador = 0;//Variável para ir incrementado até atingir o valor do delay, só aí é que a informação é enviada para evitar repetir.

	time(&start); //Começou a simulação

	Fechar(&controlaNrUtilizadores);
	while(nrUtilizadoresRestantes >0)
	{

		Abrir(&controlaNrUtilizadores);
		// (...)
		// geração de números (consoante a configuração - probabilidades e etc)
		// (...)		
		if(tempoViagem==sconf.duracao_viagem)
		{
			printf("A viagem durou %d s\n",tempoViagem);
			tempoViagem=0;
			Fechar(&controlaNrUtilizadores);
			comecouViagem=0;
			Abrir(&controlaNrUtilizadores);
			fimDaViagem();
			Fechar(&controlaNrUtilizadores);
			Abrir(&controlaNrUtilizadores);
		}

		Fechar(&controlaNrUtilizadores);
		if(!comecouViagem && nrUtilizadoresRestantes < 4)
		{
			printf("Estes %i tiveram que ser expulsos, devido à falta de pessoas para a diversão\n",nrUtilizadoresRestantes);
			Abrir(&controlaNrUtilizadores);

			break;
		}
		else Abrir(&controlaNrUtilizadores);

		Fechar(&controlaNrUtilizadores);
		if(comecouViagem)
		{
			Abrir(&controlaNrUtilizadores);
			time(&tempoAtualViagem);
			tempoViagem=difftime(tempoAtualViagem,inicioViagem);
		}
		else
		{
			Abrir(&controlaNrUtilizadores);
		}

		if(contador == DELAY_ENTRE_ENVIOS)				//Delay usado para não mostrar o mesmo cliente várias vezes
		{
			contador = 0;	

			if(podeCriarCliente())				//Verificamos se é para criar um cliente
			{
				criarCliente();
			}
			if(rand() % sconf.taxa_atendimento_compra)	//Para não vender bilhetes a todos 
			{
				pthread_create(&guicheCompra,NULL,guicheCompraFunc,NULL);
			}	
			if(rand() % sconf.taxa_atendimento_dev)
			{
				pthread_create(&guicheDevolucao,NULL,filaDev,NULL);
			}		
			if(rand() % sconf.taxa_atendimento_carros)
			{
				pthread_create(&filaCarros,NULL,FilaDosCarrosSP,NULL);
			}
		}
		contador++;
		Fechar(&controlaNrUtilizadores);
	}
	Abrir(&controlaNrUtilizadores);

	time(&end);
	tempoSimul=difftime(end, start);
	hora = tempoSimul / 3600;      	//Para calcular o nr de horas
	minutosAux = tempoSimul / 60;	//Cálculo intermédio para os minutos
	minutos = minutosAux % 60;		//Para calcular os minutos
	segundos = tempoSimul % 60;		//Para calcular o número de segundos
	printf("Acabou o tempo de simulação: %d hora(s) %d minuto(s) %d segundo(s)\n",hora,minutos,segundos);

	escreverIntNoMonitor(FIM_SIMULACAO); //Avisa o Monitor que terminou a simulação
	escreverIntNoMonitor(nrUtilizadores);
	printf("---FIM---\n");
	getchar();
	return 0;
}
//Cliente entra para a fila do guiché com prioridades
void entraClienteGuicheCompraPrio(int id)
{
	Fechar(&mGCP);
	nrPessoasEspGCP++;
	printf("Número de clientes prioritários à espera no guiché: %d\n",nrPessoasEspGCP);
	Abrir(&mGCP);
	Esperar(&semGCP);
	Fechar(&mGCP);
	nrPessoasEspGCP--;
	Abrir(&mGCP);
}
//Cliente entra para a fila do guiché sem prioridades
void entraClienteGuicheCompraNaoPrio(int id)
{
	Fechar(&mGCNP);
	nrPessoasEspGCNP++;
	printf("Número de clientes não prioritários à espera no guiché: %d\n",nrPessoasEspGCNP);
	Abrir(&mGCNP);
	Esperar(&semGCNP);
	Fechar(&mGCNP);
	nrPessoasEspGCNP--;
	Abrir(&mGCNP);
}
//Para controlar as duas filas (prio e não prio) para comprar o bilhete
void * guicheCompraFunc()
{
	Fechar(&mGCP);
	if(nrPessoasEspGCP>0)
	{
		Abrir(&mGCP);
		Assinalar(&semGCP);
		//servico();
	}
	else 
	{
		Abrir(&mGCP);
		Fechar(&mGCNP);
		if(nrPessoasEspGCNP>0)
		{
			Abrir(&mGCNP);
			Assinalar(&semGCNP);
			//servico();
		}
		else Abrir(&mGCNP);
	}
	Abrir(&mGCP);

}
/***************************************************************************************************************************/
/**GUICHÉ DE DEVOLUÇÃO**************************************************************************************************/
/***************************************************************************************************************************/
int entraClienteDev(utilizador * c)
{
	time_t timeChegDev,timeFimDev;
	Fechar(&mDev);
	if(nrPessoasEspDev < sconf.max_pessoas_dev)
	{
		Abrir(&mDev);
		time(&timeChegDev);
		Fechar(&mDev);
		nrPessoasEspDev++;
		Assinalar(&semClienteDev);	//Assinalar que já existe clientes a espera.Inicializado a 0.
		Abrir(&mDev);

		Esperar(&semDev);

		//servico();

		time(&timeFimDev);
		c->tempoEspDev=difftime(timeFimDev,timeChegDev);

		printf("O cliente %d demorou %d na fila da devolução\n",c->id,c->tempoEspDev);
		return 1;
	}
	else
	{
		Abrir(&mDev);
		return 0;
	}
}
void * filaDev()
{
	Esperar(&semClienteDev);
	
	//servico();

	Fechar(&mDev);
	nrPessoasEspDev--;
	Abrir(&mDev);

	Assinalar(&semDev);
}
int veSeDesiste(utilizador * c)
{
	if(rand() % sconf.prob_desistencia)
	{
		return entraClienteDev(c);
	}
	else
	{
		return CLIENTE_NAO_DESISTE;
	}
}
/***************************************************************************************************************************/
/**CARROS DA MONTANHA-RUSSA********************************************************************************************/
/***************************************************************************************************************************/
void *FilaDosCarrosSP()
{
	Fechar(&mCarrosSP);
	if(nPessoasnoscarros ==4)		//O 4 é o número de pessoas no total 
	{
		int j;
		for(j=1;j<=4;j++)
		Assinalar(&sCarros);
	}
	Abrir(&mCarrosSP);
}
void fimDaViagem()
{
	int i=1;
	Fechar(&controlaNrUtilizadores);
	nrUtilizadoresRestantes-=4;
	Abrir(&controlaNrUtilizadores);
	while(i<=4)
	{
		Fechar(&controlaNrUtilizadores);
		if((i%2)==0 && nrUtilizadoresRestantes>=4 )
		{
			Abrir(&controlaNrUtilizadores);
			Assinalar(&sCarros1);
			printf("Assinalou carro 1\n");
		}
		else if((i%2)!=0 && nrUtilizadoresRestantes>=4)
		{
			Abrir(&controlaNrUtilizadores);
			Assinalar(&sCarros2);
			printf("Assinalou carro 2\n");
		}
		else {Abrir(&controlaNrUtilizadores);}
	i++;	
	}
	Fechar(&controlaNrUtilizadores);
	nrViagens++;
	escreverIntNoMonitor(4); ///Código para enviar o nr total de viagens
	escreverIntNoMonitor(nrViagens);
	Abrir(&controlaNrUtilizadores);
}
void entraclienteCarrosSP(utilizador * c)
{
	Fechar(&controlaNrUtilizadores);
	if(nrUtilizadoresRestantes>=4)
	{
		Abrir(&controlaNrUtilizadores);
		Fechar(&mCarrosSP);
		if(tipo==1)
		{	tipo=2;	
			clientesEsperacarro1++;
			Abrir(&mCarrosSP);
			printf("O cliente %d está à espera do carro 1\n",c->id);
			Esperar(&sCarros1);
			printf("O cliente %d entrou no carro 1\n",c->id);
			Fechar(&mCarrosSP);
			clientesEsperacarro1--;
			Abrir(&mCarrosSP);
		}
		else if(tipo == 2)
		{
			tipo =1;
			clientesEsperacarro2++;
			Abrir(&mCarrosSP);
			printf("O cliente %d está à espera do carro 2\n",c->id);
			Esperar(&sCarros2);
			printf("O cliente %d entrou no carro 2\n",c->id);
			Fechar(&mCarrosSP);
			clientesEsperacarro2--;
			Abrir(&mCarrosSP);
		}
		Fechar(&mCarrosSP);
		nPessoasnoscarros++;
		Abrir(&mCarrosSP);
		Esperar(&sCarros);
		time(&inicioViagem);
		printf("A viagem começou com os cliente:%d \n",c->id);
		Fechar(&mCarrosSP);
		nPessoasnoscarros--;
		Abrir(&mCarrosSP);
		Fechar(&controlaNrUtilizadores);
		comecouViagem=1;
		Abrir(&controlaNrUtilizadores);
   	}
	else
	 {
		printf("%d\n",nrUtilizadoresRestantes);
		Abrir(&controlaNrUtilizadores);
		entraClienteDev(c);
		printf("Desistencia forcada\n");
	 }
}
/***************************************************************************************************************************/
/**FUNÇÕES AUXILIARES*****************************************************************************************************/
/***************************************************************************************************************************/
void escreverNoMonitor(char message[])
{
	write(s,message,BUFFER_SIZE);
}
void escreverIntNoMonitor(int x)
{
	char message[BUFFER_SIZE];
	sprintf(message,"%i",x);
	escreverNoMonitor(message);
}
//Função gerar se é para criar um cliente ou não
int podeCriarCliente()
{
	int permissao = rand() % sconf.prob_chegar_pessoas;
	if(permissao && nrUtilizadores < sconf.max_pessoas_total)
	{
		return CLIENTE_E_CRIADO;
	}
	else
	{
		return CLIENTE_NAO_E_CRIADO;
	}
}

//Função para criar a tarefa do clientes
void criarCliente()
{
		Fechar(&mSimulador);
		nrUtilizadores++;
		Abrir(&mSimulador);

		pthread_t cliente;
		pthread_create(&cliente,NULL,cliente_act,(void *)(intptr_t)(randWithProb(0.5)));
}

//Função que vai controlar as ações dos clientes
void * cliente_act(void *prio)
{
	time_t tempoChegadaG,TempoSaidaG;
	Fechar(&mSimulador);
	utilizador c;
	c.id=nrUtilizadores;
	c.prioritarios=(int *)prio;
	c.estado=0;
	c.tempoEspGuiche=0;
	c.tempoEspCarros=0;
	c.emViagem=0;
	Abrir(&mSimulador);

	char log[BUFFER_SIZE];
	sprintf(log,"Chegou o cliente com o id %d e prioridade %d\n",c.id,(int)(intptr_t)c.prioritarios);
	printf("%s",log);
	escreverNoLog(log);

	Fechar(&mSimulador);
	if(c.prioritarios)
	{
		
		//Começar a contar o tempo de espera no guiche
		time(&tempoChegadaG);
		Abrir(&mSimulador);
		entraClienteGuicheCompraPrio(c.id);
		//Acabar a contagem
		time(&TempoSaidaG);
		Fechar(&mSimulador);
		c.tempoEspGuiche=difftime(TempoSaidaG, tempoChegadaG);
		escreverIntNoMonitor(COMPRA_BILHETE);
		escreverIntNoMonitor(c.id);
		escreverIntNoMonitor(c.tempoEspGuiche);
		Abrir(&mSimulador);
		Fechar(&mDesistencias);
		if(veSeDesiste(&c))
		{
			nrDesistencias++;
			Abrir(&mDesistencias);

			Fechar(&controlaNrUtilizadores);
			nrUtilizadoresRestantes--;
			Abrir(&controlaNrUtilizadores);

			escreverIntNoMonitor(DESISTENCIA);
			escreverIntNoMonitor(c.id);
			Fechar(&mDesistencias);
			escreverIntNoMonitor(nrDesistencias);
			Abrir(&mDesistencias);
			escreverIntNoMonitor(c.tempoEspDev);
		}
		else
		{	
			Abrir(&mDesistencias);
			entraclienteCarrosSP(&c);
		}
	}
	else
	{
		Abrir(&mSimulador);
		//Começar a contar o tempo de espera no guiche
		time(&tempoChegadaG);
		entraClienteGuicheCompraNaoPrio(c.id);
		//Acabar a contagem
		time(&TempoSaidaG);
		Fechar(&mSimulador);
		c.tempoEspGuiche=difftime(TempoSaidaG, tempoChegadaG);
		escreverIntNoMonitor(COMPRA_BILHETE);
		escreverIntNoMonitor(c.id);
		escreverIntNoMonitor(c.tempoEspGuiche);
		Abrir(&mSimulador);
		Fechar(&mDesistencias);
		if(veSeDesiste(&c))
		{	
			nrDesistencias++;
			Abrir(&mDesistencias);

			Fechar(&controlaNrUtilizadores);
			nrUtilizadoresRestantes--;
			Abrir(&controlaNrUtilizadores);

			escreverIntNoMonitor(DESISTENCIA);
			escreverIntNoMonitor(c.id);
			Fechar(&mDesistencias);
			escreverIntNoMonitor(nrDesistencias);
			Abrir(&mDesistencias);
			escreverIntNoMonitor(c.tempoEspDev);
		}
		else
		{
			Abrir(&mDesistencias);
			entraclienteCarrosSP(&c);
		}
	}
	Abrir(&mSimulador);
	// (...)
}
